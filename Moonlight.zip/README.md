# Moonlight

Moonlight Android client project.

## Build on GitHub Actions

1. Create a GitHub repository.
2. Add this workflow file to the repository at `.github/workflows/android-build.yml` (GitHub only recognizes workflow files stored at this path; it does not run workflow files embedded inside an uploaded ZIP).
3. Upload `Moonlight.zip` to the repository root and commit it.
4. Open the **Actions** tab and select **Moonlight Android APK**.
5. When the run completes successfully, open the run and download the **Moonlight-APK** artifact.

The workflow extracts `Moonlight.zip` and runs `:app:assembleDebug`.
