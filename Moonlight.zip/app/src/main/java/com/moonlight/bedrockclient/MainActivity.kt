package com.moonlight.bedrockclient

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnLaunch = findViewById<Button>(R.id.btnLaunch)
        val btnSettings = findViewById<Button>(R.id.btnSettings)

        btnLaunch.setOnClickListener {
            checkPermissionsAndLaunch()
        }

        btnSettings.setOnClickListener {
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }
    }

    private fun checkPermissionsAndLaunch() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Please grant Overlay Permission to draw Moon Icon over Minecraft", Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, 123)
        } else {
            launchLeviStyleMinecraft()
        }
    }

    private fun launchLeviStyleMinecraft() {
        val targetLibPath = "/data/data/com.mojang.minecraftpe/files/libcustom_mod.so"
        val success = NativeInjector.injectModLibrary(targetLibPath)

        if (success) {
            Toast.makeText(this, "Native payload initialized successfully!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Native load prepped for target process", Toast.LENGTH_SHORT).show()
        }

        val serviceIntent = Intent(this, FloatingOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }

        val launchIntent = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
        if (launchIntent != null) {
            startActivity(launchIntent)
        } else {
            Toast.makeText(this, "Minecraft Bedrock (1.26.60) not installed!", Toast.LENGTH_LONG).show()
        }
    }
}
