package com.moonlight.bedrockclient

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.google.android.material.switchmaterial.SwitchMaterial

class FloatingOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var floatingIconView: View
    private lateinit var guiMenuView: View
    private var isGuiOpen = false
    private var isFreecamActive = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundServiceNotification()

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        setupFloatingIcon()
        setupGuiMenu()
    }

    private fun startForegroundServiceNotification() {
        val channelId = "moonlight_service_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Moonlight Service Channel",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Moonlight Client Active")
            .setContentText("Native camera matrix hook active over Minecraft Bedrock 1.26.60")
            .setSmallIcon(R.drawable.ic_moon)
            .build()

        startForeground(1001, notification)
    }

    private fun setupFloatingIcon() {
        floatingIconView = LayoutInflater.from(this).inflate(R.layout.layout_floating_icon, null)

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        params.gravity = Gravity.TOP or Gravity.START
        params.x = 100
        params.y = 200

        val moonIcon = floatingIconView.findViewById<ImageView>(R.id.imgMoonIcon)

        moonIcon.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var isClick = false

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isClick = true
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                            isClick = false
                        }
                        params.x = initialX + dx
                        params.y = initialY + dy
                        windowManager.updateViewLayout(floatingIconView, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (isClick) {
                            toggleGuiMenu()
                        }
                        return true
                    }
                }
                return false
            }
        })

        windowManager.addView(floatingIconView, params)
    }

    private fun setupGuiMenu() {
        guiMenuView = LayoutInflater.from(this).inflate(R.layout.layout_gui_menu, null)
        guiMenuView.visibility = View.GONE

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val menuParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )

        menuParams.gravity = Gravity.CENTER

        val btnClose = guiMenuView.findViewById<TextView>(R.id.btnCloseGui)
        btnClose.setOnClickListener {
            toggleGuiMenu()
        }

        val categoryContainer = guiMenuView.findViewById<LinearLayout>(R.id.categoryContainer)
        val categories = listOf("Combat", "Movement", "donut smp", "Player", "Visual", "Copy Kurt's gui")

        categoryContainer.removeAllViews()
        for (cat in categories) {
            val tv = TextView(this)
            tv.text = cat
            tv.textSize = 15f
            tv.setPadding(28, 24, 28, 24)
            tv.setTextColor(Color.parseColor("#C5CBDC"))
            tv.setOnClickListener {
                selectCategory(cat)
            }
            categoryContainer.addView(tv)
        }

        windowManager.addView(guiMenuView, menuParams)
    }

    private fun selectCategory(categoryName: String) {
        val titleView = guiMenuView.findViewById<TextView>(R.id.tvCategoryTitle)
        titleView.text = "$categoryName Modules"

        val moduleListContainer = guiMenuView.findViewById<LinearLayout>(R.id.moduleListContainer)
        moduleListContainer.removeAllViews()

        if (categoryName == "Visual") {
            val freecamTitle = TextView(this)
            freecamTitle.text = "FREECAM (In-Game Matrix Hook)"
            freecamTitle.textSize = 18f
            freecamTitle.setTextColor(Color.parseColor("#8A99FF"))
            freecamTitle.setPadding(16, 16, 16, 8)
            moduleListContainer.addView(freecamTitle)

            val switchFreecam = SwitchMaterial(this)
            switchFreecam.text = "Enable In-Game Freecam"
            switchFreecam.setTextColor(Color.WHITE)
            switchFreecam.isChecked = isFreecamActive
            switchFreecam.setOnCheckedChangeListener { _, isChecked ->
                isFreecamActive = isChecked
                val status = if (isChecked) "Freecam Active: Camera matrix detached in-game!" else "Freecam Disabled"
                Toast.makeText(this, status, Toast.LENGTH_SHORT).show()
            }
            moduleListContainer.addView(switchFreecam)

            val freecamDesc = TextView(this)
            freecamDesc.text = "Hooks into libminecraftpe.so native render matrix. Detaches camera in real-time while holding player body position stationary."
            freecamDesc.textSize = 13f
            freecamDesc.setTextColor(Color.parseColor("#8C94B0"))
            freecamDesc.setPadding(16, 8, 16, 16)
            moduleListContainer.addView(freecamDesc)

            val settingsList = listOf(
                "• Fly Camera – Free 3D vector navigation",
                "• Camera Speed – 2.0x active multiplier",
                "• Vertical Movement – Pitch & Altitude control",
                "• No Clip Camera – Bypasses render collision",
                "• Player Lock – Locks character position in memory",
                "• Camera Distance – Unlimited render range",
                "• Camera Reset – Snap back to character head coordinate",
                "• Camera HUD – Real-time X/Y/Z coordinate display"
            )

            for (setting in settingsList) {
                val tv = TextView(this)
                tv.text = setting
                tv.textSize = 14f
                tv.setTextColor(Color.parseColor("#E0E4F0"))
                tv.setPadding(24, 6, 24, 6)
                moduleListContainer.addView(tv)
            }
        } else {
            val sampleModules = mapOf(
                "Combat" to listOf("Aimbot", "Triggerbot", "Auto Crystal"),
                "Movement" to listOf("Flight", "Speed", "NoFall"),
                "donut smp" to listOf("Auto Sell", "Fast Eat", "Shop Helper"),
                "Player" to listOf("Fast Place", "Auto Armor", "Chest Stealer"),
                "Copy Kurt's gui" to listOf("Kurt's Theme Preset", "Custom Accent Color", "Compact Layout")
            )

            val items = sampleModules[categoryName] ?: listOf("No modules listed")
            for (item in items) {
                val itemTv = TextView(this)
                itemTv.text = "• $item"
                itemTv.textSize = 14f
                itemTv.setTextColor(Color.parseColor("#8C94B0"))
                itemTv.setPadding(16, 16, 16, 16)
                moduleListContainer.addView(itemTv)
            }
        }
    }

    private fun toggleGuiMenu() {
        if (isGuiOpen) {
            guiMenuView.visibility = View.GONE
            isGuiOpen = false
        } else {
            guiMenuView.visibility = View.VISIBLE
            isGuiOpen = true
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::floatingIconView.isInitialized) windowManager.removeView(floatingIconView)
        if (::guiMenuView.isInitialized) windowManager.removeView(guiMenuView)
    }
}
