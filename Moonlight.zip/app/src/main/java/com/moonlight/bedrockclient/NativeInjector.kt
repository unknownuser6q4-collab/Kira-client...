package com.moonlight.bedrockclient

import android.util.Log

object NativeInjector {
    private const val TAG = "MoonlightNativeInjector"

    init {
        try {
            System.loadLibrary("levi_injector")
            Log.i(TAG, "levi_injector native library loaded successfully.")
        } catch (e: UnsatisfiedLinkError) {
            Log.e(TAG, "Failed to load levi_injector library: ${e.message}")
        }
    }

    external fun injectModLibrary(libraryPath: String): Boolean
}
