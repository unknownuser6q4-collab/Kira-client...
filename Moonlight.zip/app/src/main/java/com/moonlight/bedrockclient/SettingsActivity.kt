package com.moonlight.bedrockclient

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val switchKurt = findViewById<SwitchMaterial>(R.id.switchKurtStyle)
        switchKurt.setOnCheckedChangeListener { _, isChecked ->
            val status = if (isChecked) "Kurt's GUI Enabled" else "Standard GUI Enabled"
            Toast.makeText(this, status, Toast.LENGTH_SHORT).show()
        }
    }
}
