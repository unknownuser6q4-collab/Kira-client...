#!/system/bin/sh

TARGET_PKG="com.mojang.minecraftpe"
FILES_DIR="/data/data/${TARGET_PKG}/files"
LIB_DIR="${FILES_DIR}/lib"

export LD_PRELOAD="${LIB_DIR}/libcustom_mod.so"

log -p i -t "wrap.sh" "Preloading ${LD_PRELOAD} for process: $@"

exec "$@"
