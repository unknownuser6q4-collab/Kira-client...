#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <cstdio>
#include <cstdlib>

#define LOG_TAG "LeviStyleInjector"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_moonlight_bedrockclient_NativeInjector_injectModLibrary(
    JNIEnv* env,
    jobject clazz,
    jstring libraryPath) {

    const char* native_path = env->GetStringUTFChars(libraryPath, nullptr);
    LOGI("LeviLauncher-style Native Injector target path: %s", native_path);

    chmod(native_path, 0755);

    void* handle = dlopen(native_path, RTLD_NOW | RTLD_GLOBAL);
    if (!handle) {
        LOGE("Levi-style dlopen failed: %s", dlerror());
        env->ReleaseStringUTFChars(libraryPath, native_path);
        return JNI_FALSE;
    }

    LOGI("Dynamic library successfully mapped at address: %p", handle);

    typedef void (*InitFunc)();
    dlerror();
    
    InitFunc init_fn = reinterpret_cast<InitFunc>(dlsym(handle, "initialize_mod"));
    const char* err = dlerror();
    if (err != nullptr) {
        LOGE("Symbol lookup 'initialize_mod' failed: %s", err);
        env->ReleaseStringUTFChars(libraryPath, native_path);
        return JNI_FALSE;
    }

    LOGI("Executing initialize_mod() inside target process...");
    init_fn();

    env->ReleaseStringUTFChars(libraryPath, native_path);
    return JNI_TRUE;
}

}

__attribute__((constructor))
void on_levi_injector_init() {
    LOGI("LeviStyleInjector initialized in PID: %d", getpid());
}
