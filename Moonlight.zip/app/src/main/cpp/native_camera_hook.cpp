#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <cstdio>
#include <cstdlib>
#include <unistd.h>
#include <cstdint>

#define LOG_TAG "MoonlightFreecamNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

struct Vec3 {
    float x, y, z;
};

struct CameraTransform {
    Vec3 position;
    Vec3 rotation;
    float fov;
};

static bool g_freecam_active = false;
static CameraTransform g_original_camera;
static CameraTransform g_freecam_camera;
static float g_camera_speed = 2.0f;
static bool g_player_locked = true;

extern "C" {

void update_in_game_camera(CameraTransform* current_camera, Vec3* player_pos) {
    if (!current_camera || !player_pos) return;

    if (g_freecam_active) {
        if (g_player_locked) {
            player_pos->x = g_original_camera.position.x;
            player_pos->y = g_original_camera.position.y;
            player_pos->z = g_original_camera.position.z;
        }

        current_camera->position = g_freecam_camera.position;
        current_camera->rotation = g_freecam_camera.rotation;
    }
}

JNIEXPORT void JNICALL
toggle_native_freecam(bool enable) {
    g_freecam_active = enable;
    LOGI("In-Game Native Freecam state: %s", enable ? "ACTIVE (Camera Detached)" : "INACTIVE");
}

JNIEXPORT void JNICALL
set_camera_speed(float speed) {
    g_camera_speed = speed;
    LOGI("Freecam movement speed set to: %.2f", speed);
}

}
