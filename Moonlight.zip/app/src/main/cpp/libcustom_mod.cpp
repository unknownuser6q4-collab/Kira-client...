#include <android/log.h>
#include <dlfcn.h>
#include <cstdio>
#include <cstdlib>
#include <unistd.h>

#define LOG_TAG "MoonlightLoader"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

typedef void (*InitFuncPtr)();

__attribute__((constructor))
void on_library_loaded() {
    LOGI("Preload constructor executed in PID: %d", getpid());
    
    const char* target_lib_path = "/data/data/com.mojang.minecraftpe/files/libpayload.so";
    LOGI("Attempting to load payload library: %s", target_lib_path);
    
    void* handle = dlopen(target_lib_path, RTLD_NOW | RTLD_GLOBAL);
    if (!handle) {
        LOGE("dlopen failed for %s: %s", target_lib_path, dlerror());
        return;
    }

    LOGI("Payload library opened successfully at handle: %p", handle);
    dlerror();

    InitFuncPtr init_mod = reinterpret_cast<InitFuncPtr>(dlsym(handle, "initialize_mod"));
    const char* dlsym_error = dlerror();
    
    if (dlsym_error != nullptr) {
        LOGE("Failed to locate symbol 'initialize_mod': %s", dlsym_error);
        return;
    }

    LOGI("Executing 'initialize_mod' entry point...");
    init_mod();
    LOGI("'initialize_mod' execution complete.");
}
