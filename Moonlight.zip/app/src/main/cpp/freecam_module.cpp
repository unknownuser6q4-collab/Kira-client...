#include <android/log.h>
#include <dlfcn.h>
#include <cstdio>
#include <cstdlib>
#include <unistd.h>

#define LOG_TAG "MoonlightFreecam"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

struct FreecamConfig {
    bool enabled = false;
    float cameraSpeed = 2.0f;
    bool noClip = true;
    bool playerLock = true;
    bool smoothCamera = true;
    bool cameraHud = true;
    float posX = 0.0f;
    float posY = 0.0f;
    float posZ = 0.0f;
};

static FreecamConfig g_freecamConfig;

extern "C" {

void toggle_freecam(bool state) {
    g_freecamConfig.enabled = state;
    LOGI("Freecam status updated: %s", state ? "ENABLED" : "DISABLED");
}

void reset_camera_position() {
    LOGI("Freecam position reset to player stationary coordinates.");
}

}
