# Moonlight app-specific ProGuard/R8 rules.
# Keep JNI entry points and native method declarations.
-keepclasseswithmembernames class * {
    native <methods>;
}
