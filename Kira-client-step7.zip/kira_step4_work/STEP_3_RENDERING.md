# Step 3 — rendering pipeline foundation

This step adds a bounded, thread-safe native render-command queue and an adapter to
the rendering callbacks already declared in the version-gated game bridge.

## Added files

- `app/src/main/cpp/render_pipeline.h/.cpp`
  - `FrameRenderer` owns frame lifecycle and queued commands.
  - Supports 2D lines, 2D outline rectangles (expanded to four lines), 2D text,
    and 3D axis-aligned boxes.
  - Rejects invalid dimensions, NaN/Inf coordinates, inverted 3D bounds, empty or
    oversized text, stale frame IDs, and command-buffer overflow.
  - `GameBridgeBackend` forwards commands to `GameIntegration`; its existing
    version/build-ID checks and capability checks remain in force.
- `tests/render_pipeline_smoke.cpp`
  - Exercises frame validation, command conversion, queue limits, backend failures,
    and delegation to registered mock provider callbacks.
- `scripts/test-render-pipeline.sh`
  - Builds and runs the portable native rendering tests with the host C++ compiler.

## How the game provider is expected to use it

A version-specific provider must be registered from code running in the game process.
It must supply the 2D/3D drawing callbacks only when it can draw using the actual
Minecraft render context. The client-side integration then creates a
`GameIntegration` with the exact verified version and build ID, calls `refresh()`,
creates `GameBridgeBackend` (which refreshes provider state at each frame start), queues module visuals during a frame, and calls
`FrameRenderer::flush()` from the provider's real game-render callback on the render
thread/context.

The intended sequence is:

1. Verify exact game version and build ID.
2. Begin a frame using the game's framebuffer dimensions and monotonically increasing
   frame ID.
3. Queue visual commands from modules.
4. Flush only from the real game render callback.
5. End the provider's render frame and handle any callback failure.

2D coordinates are pixel coordinates in the provider's agreed viewport coordinate
space. 3D box bounds are provider-defined world-space coordinates. The provider must
apply its actual camera/view/projection and render-state handling.

## Explicit limits — what this step does not do

- It does not discover or install a Minecraft render hook.
- It does not create an EGL context or take over Minecraft's OpenGL state.
- It does not implement a Minecraft-specific drawing provider.
- It does not draw into Minecraft merely because the Moonlight Android app loads
  `libmoonlight_engine.so`.
- It does not make ESP, Tracers, BlockESP, NameTags, or other gameplay modules
  functional on its own.

Those require the exact target APK, verified game-side render callback/provider, and
module-specific data/projection implementations. A separately drawn Android overlay
is not the same as rendering inside Minecraft.

## Verification

Run:

```bash
scripts/test-native-bridge.sh
scripts/test-render-pipeline.sh
python3 -m unittest discover -s tests -p 'test_*.py'
```

The render smoke test uses fake callbacks. It proves the command queue and adapter
behave as specified; it does not prove that Minecraft itself has registered a provider
or rendered any commands.
