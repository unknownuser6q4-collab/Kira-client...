# Module integration status (source audit)

## What this update adds

- A versioned C ABI contract for an **in-process game integration provider**: `app/src/main/cpp/game_bridge_api.h`.
- A registry that validates the provider ABI and only reports capabilities whose required callbacks are present: `game_bridge_registry.cpp`.
- A typed integration facade that requires an exact game version and build ID before allowing calls: `game_integration.h/.cpp`.
- ABI v4 includes provider-supplied build identity, input-state callback, explicit player classification, world-to-screen projection and entity-name callbacks; capabilities are filtered unless required callbacks exist.
- Native storage for each module setting, including JNI methods to set and clear values.
- Kotlin configuration synchronization now forwards saved setting values to the native mirror.
- A safe build workflow that no longer ships a signing keystore/password in the repository.

## Important boundary

This repository still does **not** contain a Minecraft Bedrock 1.26.60 in-process provider. The bridge API and new typed facade are contracts/consumer-side code, not a Minecraft hook, injector, symbol map, or game implementation. It cannot discover private game structures by itself. A separate provider must be built and tested against the exact installed game build and must register the callbacks in `game_bridge_api.h` from inside the game process. Until then, gameplay modules remain unavailable. The overlay, GUI, settings persistence, and native configuration mirror can work without that provider.

Do not mark a module as functional merely because it is listed, enabled in the GUI, or stored by JNI.

## Existing module inventory

| Module ID | Feature | Current state after this update |
|---|---|---|
| `fullbright` | World lighting | UI/config + native setting mirror; needs provider callback and implementation |
| `freecam` | Detached camera | UI/config + native setting mirror; needs camera provider and implementation |
| `freelook` | Independent look | UI/config + native setting mirror; needs camera/input provider and implementation |
| `storage_esp` | Storage block outlines | UI/config + native setting mirror; needs block query + 3D rendering provider |
| `geode_finder` | Geode detection | UI/config + native setting mirror; needs block/world query provider |
| `light_finder` | Light source search | UI/config + native setting mirror; needs block/world query provider |
| `sus_chunk` | Chunk activity heuristics | UI/config + native setting mirror; needs chunk/block/player data provider |
| `block_esp` | Selected block outlines | UI/config + native setting mirror; needs block query + 3D rendering provider |
| `stash_finder` | Container cluster search | UI/config + native setting mirror; needs block query provider |
| `logout_spots` | Disconnect location markers | UI/config + native setting mirror; needs player/session event provider |
| `player_esp` | Player boxes/tracers/names/distance | Native details path draws player boxes, tracers, names and distance labels only with provider-supplied classification, projection and name callbacks; still requires a real Bedrock provider and in-game verification |
| `spectator_glow` | Spectator highlighting | UI/config + native setting mirror; needs entity state + rendering provider |
| `aimbot` | Aim assistance | UI/config + native setting mirror; needs entity, camera and input provider |
| `triggerbot` | Target-triggered action | UI/config + native setting mirror; needs target and input provider |
| `reach` | Interaction distance | UI/config + native setting mirror; requires a verified game interaction interface |
| `velocity` | Knockback handling | UI/config + native setting mirror; requires a verified player-motion interface |
| `autoclicker` | Automated clicks | UI/config + native setting mirror; needs input provider |
| `hitbox` | Entity-bounds visualization | Native module runtime now consumes validated snapshots and queues 3D bounds; still needs a real Bedrock provider/render callback and in-game verification |
| `flight` | Flight movement | UI/config + native setting mirror; requires a verified player movement interface |
| `freeze` | Movement freeze | UI/config + native setting mirror; requires a verified player movement interface |
| `elytra_fly` | Elytra movement | UI/config + native setting mirror; requires movement and player-state provider |
| `no_fall` | Fall handling | UI/config + native setting mirror; requires a verified player-state/gameplay interface |
| `sprint` | Sprint control | UI/config + native setting mirror; requires player movement/input provider |
| `keep_sprint` | Sprint persistence | UI/config + native setting mirror; requires player movement provider |
| `bhop` | Auto-jump | UI/config + native setting mirror; requires player movement/input provider |
| `scaffold` | Block placement helper | UI/config + native setting mirror; requires block, inventory and placement interfaces |
| `hud` | Overlay status HUD | Android overlay implementation exists; it is not an in-game renderer |

## Provider implementation checklist

A real provider still needs to:

1. Run inside the target Minecraft process through a separately built, authorized integration path.
2. Verify the exact Minecraft version/build and ARM64 ABI before exposing any callbacks.
3. Populate `MoonlightGameBridgeV1` with only callbacks it genuinely implements.
4. Call `moonlight_game_bridge_register_v1()` after initialization and unregister during shutdown.
5. Implement game-thread-safe player/entity/world reads and render/input callbacks.
6. Marshal calls onto the correct game/render thread; do not call game APIs from the Android overlay thread.
7. Reject unsupported versions rather than using guessed offsets or stale symbol addresses.
8. Add provider-side tests and an in-game test for every module before marking it functional.

## Build and signing

The GitHub Actions workflow now builds a debug APK using the runner's temporary debug key. The old committed `.jks` and plaintext password were removed from this archive because a public repository must not contain a signing private key. Configure a private release key outside source control before distributing a release build. Existing installations signed with the removed key may need uninstall/reinstall when changing signing identity.


## Step 2 status

The client-side, version/build-gated integration facade is implemented and covered
by host-side smoke tests. It requires a non-empty exact version and build ID and
returns explicit errors when the provider is detached, incompatible, missing a
capability, or fails a callback. The provider itself is not present, and no live
Minecraft test has been performed. See [STEP_2_INTEGRATION_LAYER.md](STEP_2_INTEGRATION_LAYER.md).


## Step 3 status — rendering pipeline foundation

The client-side rendering command queue and `GameBridgeBackend` adapter are now
implemented. Supported command types are 2D lines, 2D outline rectangles, 2D text,
and 3D axis-aligned boxes. The queue validates frame dimensions, frame IDs, finite
coordinates, text limits and command capacity. The game adapter refreshes the provider
identity at each frame start and delegates through the existing build-gated bridge.

This is not an actual Minecraft render hook or provider. A version-specific provider
must still call the renderer from Minecraft's real render callback and implement the
provider drawing callbacks using the correct game render context. No visual gameplay
module has been proven in-game. See [STEP_3_RENDERING.md](STEP_3_RENDERING.md).


## Step 4 update — world data foundation

A bounded read-only snapshot consumer now validates player/entity records and wraps block queries (`world_snapshot.h/.cpp`). It requires an exact-version/exact-build provider. This is not a Bedrock provider and does not make the listed gameplay modules functional; all game-side feature implementation remains pending provider work and real in-game testing.


## Step 5 update — first executable module runtime

`module_runtime.h/.cpp` connects the native `ModuleManager`, `WorldSnapshotReader`, and
`FrameRenderer`. The first implemented module is `hitbox`: when enabled, it draws validated
3D bounds for alive entities inside the configured `hitbox.range` (default 64 blocks,
clamped to 512). The runtime is read-only: it does not modify player movement, world state,
or entity state. Since the current bridge does not identify player entity types, this
module visualizes provider-reported entities generally; it does not claim player-only ESP.

The host-side smoke test uses a fake provider and fake renderer. This verifies the module
execution path and range/alive filtering, not Minecraft attachment or live rendering. Other
modules remain UI/config-only until their required provider interfaces and implementations
are added. See [STEP_5_MODULE_RUNTIME.md](STEP_5_MODULE_RUNTIME.md).


## Step 6 update — player classification and Player ESP runtime

ABI v3 adds a dedicated `is_player_entity` provider callback and capability. The registry strips that capability if the callback is missing. `ModuleRuntime::runPlayerEspFrame()` now draws entity bounds only after positive provider classification; missing/failed classification cancels the frame (fail closed). It uses `player_esp.range` (default 64, max 512). Host fixture tests verify player/non-player filtering and missing-classifier behavior. This remains client-side plumbing tested with fake providers/renderers, not a live Minecraft feature. A verified Bedrock provider and actual render-thread callback are still required. See [STEP_6_PLAYER_ESP.md](STEP_6_PLAYER_ESP.md).


## Step 7 update — Player ESP details

ABI v4 adds two explicit provider callbacks: world-to-screen projection in the same viewport coordinate space as the 2D renderer, and bounded UTF-8 entity-name retrieval. The registry strips each capability if its callback is absent. `ModuleRuntime::runPlayerEspDetailsFrame()` can draw player-only 3D boxes, bottom-center tracers, names and one-decimal distance labels. Settings `player_esp.tracers`, `player_esp.names`, and `player_esp.distance` default on and accept `false`, `0`, `off`, or `no` to disable. It fails closed if player classification, projection, or requested name data is unavailable.

Host tests exercise the new path using fake projection/name callbacks and a fake renderer. This is not a Minecraft implementation: the real Bedrock provider must supply correct projection matrices, player names and render-thread callbacks for the exact installed build. Rebuild any external provider against ABI v4. See [STEP_7_PLAYER_ESP_DETAILS.md](STEP_7_PLAYER_ESP_DETAILS.md).
