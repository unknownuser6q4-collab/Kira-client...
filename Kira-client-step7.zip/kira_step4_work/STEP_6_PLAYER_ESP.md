# Step 6 — verified player classification and Player ESP path

## Added

- Bridge ABI bumped to v3. Providers must be rebuilt against the current header.
- Added `MOONLIGHT_CAP_PLAYER_CLASSIFY` and `is_player_entity(context, runtime_id, out)`.
- Registry strips the classification capability when the provider callback is absent.
- `GameIntegration` and `WorldSnapshotReader` expose a checked player-classification call.
- Added `ModuleRuntime::runPlayerEspFrame()` for the `player_esp` module.
- Player ESP draws 3D bounds only for entities the provider positively identifies as players; dead, out-of-range and non-player entities are skipped.
- Uses `player_esp.range` (default 64 blocks, clamped to 512) and a distinct box color.
- Classification errors fail closed: the frame is cancelled rather than treating unknown entities as players.
- Host tests cover positive/negative classification and missing-classifier behavior.

## Important limitations

This implements the client-side classification contract and Player ESP execution path, not the Minecraft-specific classifier. The provider must identify players using verified game data for the exact Bedrock build and call the callback safely on the appropriate game thread. The tests use a fake provider and fake renderer; they do not prove that Minecraft is attached or that boxes appear in a live game. The real Bedrock provider and render callback are still missing.

ABI v3 is intentionally incompatible with ABI v2. Any separately built provider must be rebuilt and must advertise only callbacks it genuinely implements.

## Verification

```bash
./scripts/test-native-bridge.sh
./scripts/test-render-pipeline.sh
./scripts/test-world-snapshot.sh
./scripts/test-module-runtime.sh
python3 -m unittest discover -s tests -v
```

## Superseded by Step 7

Step 7 advances the bridge to ABI v4 with projection and entity-name callbacks. Use the current `game_bridge_api.h` and [STEP_7_PLAYER_ESP_DETAILS.md](STEP_7_PLAYER_ESP_DETAILS.md) when building a provider.
