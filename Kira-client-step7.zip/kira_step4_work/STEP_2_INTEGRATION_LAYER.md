# Step 2 — version-gated native integration layer

## What this step adds

This step builds the client-side contract that a separately implemented,
version-specific Minecraft integration provider must satisfy:

- `game_bridge_api.h` now uses ABI version 2 and includes an exact game build ID.
- The bridge registry copies the version and build ID into stable storage and
  removes capabilities whose required callbacks are absent.
- `game_integration.h/.cpp` provides a typed C++ facade for player/entity/input
  reads, camera/player controls, lighting, block queries and overlay drawing.
- The facade requires both an exact game version and an exact build ID before it
  exposes any capability. A missing build ID is rejected rather than treated as
  a wildcard.
- Input-read capability is now tied to an actual callback.
- Native smoke tests cover ABI registration, capability filtering, successful
  reads, missing capabilities, build mismatch and detach behavior.

## Critical limitation

This is the **client-side integration layer**, not the Minecraft provider. No
Minecraft APK was supplied for this step, so this repository still does not have
verified 1.26.60 symbols, layouts, callbacks, an in-process loader, or a working
provider. The facade deliberately refuses to become ready until a provider
registers a matching version and build ID.

Do not fill the build ID with a guessed value. Obtain the target APK's SHA-256 and
native-library/build metadata using Step 1 first. A whole-APK SHA-256 can be used
as an audit identity, but the provider should also record the exact game library
identity it was built and tested against.

## Provider contract

A provider must be developed and tested separately for the exact target build.
It must:

1. Run only through an authorized integration path in a game process you control.
2. Verify package, version, ABI and the exact native build identity before
   registering any callbacks.
3. Implement only callbacks whose behavior and thread requirements are known.
4. Set a capability bit only when every callback required by that capability is
   implemented and validated.
5. Register a `MoonlightGameBridgeV1` structure using ABI version 2.
6. Keep callback code and its `context` alive while registered; stop/join any
   callback work before unregistering.
7. Marshal game and render operations onto the correct game/render thread. The
   Android overlay thread must not call game APIs directly.
8. Return failure for unavailable data or unsupported operations; never return
   fabricated player/entity/world values.
9. Unregister on provider shutdown and reject unknown game builds.
10. Include provider-side unit tests and in-game tests for every exposed callback.

The bridge API is intentionally a contract. It does not resolve private symbols,
provide offsets, patch a game binary, inject a library, or bypass platform
protections. Those details cannot be safely or accurately authored without the
actual target binary and a verified, authorized integration method.

## API use

The provider calls `moonlight_game_bridge_register_v1()` after validating the
running build. The client creates `moonlight::integration::GameIntegration` with
the expected version and build ID, then calls `refresh()`. Only `Result::Ok`
means the provider is attached and the identity matches. Each operation returns a
specific result (`Detached`, `VersionMismatch`, `BuildMismatch`,
`CapabilityMissing`, or `CallbackFailed`) rather than pretending success.

Example consumer-side pattern:

```cpp
moonlight::integration::GameIntegration game("1.26.60", verifiedBuildId);
if (game.refresh() == moonlight::integration::Result::Ok) {
    MoonlightPlayerStateV1 player{};
    if (game.readPlayer(&player) == moonlight::integration::Result::Ok) {
        // Consume the verified player snapshot here.
    }
}
```

`verifiedBuildId` must come from the actual Step 1 audit/provider build process;
do not hard-code a placeholder into a release build.

## Run tests

```bash
./scripts/test-native-bridge.sh
python3 -m unittest discover -s tests -v
```

These are host-side contract tests. Passing them does not prove Minecraft
attachment, rendering, or gameplay behavior. A live provider and exact target APK
are still required for that.

## Step 2 exit criteria

- [x] A versioned provider ABI exists.
- [x] Exact version and build identity are required by the consumer facade.
- [x] Capabilities are filtered against actual callbacks.
- [x] Typed consumer methods return explicit failure states.
- [x] Host-side tests cover registration and compatibility rejection.
- [ ] Run Step 1 against the exact original Minecraft 1.26.60 APK.
- [ ] Build a provider for the audited target build using an authorized integration path.
- [ ] Validate provider callbacks in the game process.
- [ ] Demonstrate a live in-game callback and record test evidence.

Step 2 is complete as a client-side contract/facade. The game-specific provider
and live Minecraft integration remain pending and must not be represented as done.
