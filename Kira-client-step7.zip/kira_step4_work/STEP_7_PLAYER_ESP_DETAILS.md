# Step 7 — Player ESP details

## Added

- Bridge ABI bumped from v3 to v4; any separately built provider must be rebuilt.
- Added `MOONLIGHT_CAP_WORLD_TO_SCREEN` and `project_world_to_screen`, which returns a finite pixel coordinate and an explicit visibility flag in the same viewport coordinate space as the 2D renderer.
- Added `MOONLIGHT_CAP_ENTITY_NAME` and a bounded entity-name callback. The client always terminates the provided buffer.
- Registry strips each capability when its callback is missing.
- `GameIntegration` and `WorldSnapshotReader` expose checked projection and name-reading methods.
- `ModuleRuntime::runPlayerEspDetailsFrame()` adds player-only tracers, names and distance labels while retaining 3D player boxes.
- Settings: `player_esp.tracers`, `player_esp.names`, and `player_esp.distance`; all default on. Values `false`, `0`, `off`, or `no` disable the corresponding option.
- Projection, classification and requested name failures cancel the frame instead of drawing misleading data.

## Important limitations

This is the client-side contract and module execution path only. A provider must implement accurate world-to-screen projection using the current Minecraft camera matrices and viewport, retrieve actual player names, and invoke drawing on the correct render thread. No Minecraft-specific provider, camera matrix reader, symbol map, hook or live render callback is included. Host tests use fake callbacks and a fake renderer; they do not prove live in-game operation.

## Verification

```bash
./scripts/test-native-bridge.sh
./scripts/test-render-pipeline.sh
./scripts/test-world-snapshot.sh
./scripts/test-module-runtime.sh
python3 -m unittest discover -s tests -v
```
