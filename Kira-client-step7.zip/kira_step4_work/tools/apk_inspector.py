#!/usr/bin/env python3
"""Static APK inventory for Kira Client's Step 1 Minecraft audit.

This tool never installs, modifies, launches, or attaches to an APK. It reads the
APK as a ZIP archive, inventories its contents, inspects ELF metadata in native
libraries, and optionally captures Android SDK tool output.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import struct
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ABI_NAMES = {
    "armeabi-v7a": "ARM 32-bit",
    "arm64-v8a": "AArch64 / ARM64",
    "x86": "x86 32-bit",
    "x86_64": "x86-64",
    "riscv64": "RISC-V 64-bit",
}
MACHINE_NAMES = {
    3: "EM_386 (x86)",
    40: "EM_ARM (ARM)",
    62: "EM_X86_64 (x86-64)",
    183: "EM_AARCH64 (ARM64)",
    243: "EM_RISCV (RISC-V)",
}
ELF_CLASS = {1: "ELF32", 2: "ELF64"}
ELF_DATA = {1: "little-endian", 2: "big-endian"}
PT_LOAD, PT_DYNAMIC, PT_NOTE = 1, 2, 4
DT_NEEDED, DT_STRTAB, DT_STRSZ, DT_SONAME, DT_RPATH, DT_RUNPATH = 1, 5, 10, 14, 15, 29


def sha256_fileobj(fileobj: Any) -> str:
    digest = hashlib.sha256()
    for chunk in iter(lambda: fileobj.read(1024 * 1024), b""):
        digest.update(chunk)
    return digest.hexdigest()


def _unpack(fmt: str, data: bytes, offset: int = 0) -> tuple[Any, ...]:
    size = struct.calcsize(fmt)
    if offset < 0 or offset + size > len(data):
        raise ValueError("truncated ELF structure")
    return struct.unpack_from(fmt, data, offset)


def parse_elf(data: bytes) -> dict[str, Any]:
    """Return verifiable ELF header and DT_NEEDED metadata from one .so file."""
    if len(data) < 16 or data[:4] != b"\x7fELF":
        return {"is_elf": False, "reason": "missing ELF magic or truncated identification"}
    elf_class, elf_data = data[4], data[5]
    if elf_class not in ELF_CLASS or elf_data not in ELF_DATA:
        return {"is_elf": False, "reason": f"unsupported ELF class/data ({elf_class}/{elf_data})"}
    endian = "<" if elf_data == 1 else ">"
    try:
        if elf_class == 2:
            fields = _unpack(endian + "HHIQQQIHHHHHH", data, 16)
            e_type, e_machine, e_version, e_entry, e_phoff, e_shoff, e_flags, e_ehsize, e_phentsize, e_phnum, e_shentsize, e_shnum, e_shstrndx = fields
            ph_fmt = endian + "IIQQQQQQ"
            dyn_fmt = endian + "qQ"
            ph_size = struct.calcsize(ph_fmt)
            dyn_size = struct.calcsize(dyn_fmt)
        else:
            fields = _unpack(endian + "HHIIIIIHHHHHH", data, 16)
            e_type, e_machine, e_version, e_entry, e_phoff, e_shoff, e_flags, e_ehsize, e_phentsize, e_phnum, e_shentsize, e_shnum, e_shstrndx = fields
            ph_fmt = endian + "IIIIIIII"
            dyn_fmt = endian + "iI"
            ph_size = struct.calcsize(ph_fmt)
            dyn_size = struct.calcsize(dyn_fmt)
        if e_phnum > 4096 or e_phentsize < ph_size:
            raise ValueError("invalid program-header table")

        loads: list[tuple[int, int, int]] = []  # vaddr, file offset, file size
        dynamic_segment: tuple[int, int] | None = None
        notes: list[tuple[int, int]] = []
        for i in range(e_phnum):
            off = e_phoff + i * e_phentsize
            p = _unpack(ph_fmt, data, off)
            if elf_class == 2:
                p_type, p_flags, p_offset, p_vaddr, _p_paddr, p_filesz, _p_memsz, _p_align = p
            else:
                p_type, p_offset, p_vaddr, _p_paddr, p_filesz, _p_memsz, p_flags, _p_align = p
            if p_offset + p_filesz > len(data):
                continue
            if p_type == PT_LOAD:
                loads.append((p_vaddr, p_offset, p_filesz))
            elif p_type == PT_DYNAMIC:
                dynamic_segment = (p_offset, p_filesz)
            elif p_type == PT_NOTE:
                notes.append((p_offset, p_filesz))

        dyn_entries: list[tuple[int, int]] = []
        if dynamic_segment:
            d_off, d_size = dynamic_segment
            for off in range(d_off, d_off + d_size - dyn_size + 1, dyn_size):
                tag, value = _unpack(dyn_fmt, data, off)
                if tag == 0:  # DT_NULL
                    break
                dyn_entries.append((int(tag), int(value)))

        def vaddr_to_offset(vaddr: int) -> int | None:
            for seg_vaddr, seg_off, seg_filesz in loads:
                if seg_vaddr <= vaddr < seg_vaddr + seg_filesz:
                    return seg_off + (vaddr - seg_vaddr)
            return None

        strtab_addr = next((v for t, v in dyn_entries if t == DT_STRTAB), None)
        strsz = next((v for t, v in dyn_entries if t == DT_STRSZ), 0)
        strtab_off = vaddr_to_offset(strtab_addr) if strtab_addr is not None else None

        def dyn_string(index: int) -> str:
            if strtab_off is None or index < 0 or index >= strsz or strtab_off + index >= len(data):
                return ""
            end_limit = min(strtab_off + strsz, len(data))
            end = data.find(b"\0", strtab_off + index, end_limit)
            if end < 0:
                end = end_limit
            return data[strtab_off + index:end].decode("utf-8", errors="replace")

        needed = [dyn_string(v) for t, v in dyn_entries if t == DT_NEEDED]
        soname = next((dyn_string(v) for t, v in dyn_entries if t == DT_SONAME), None)
        rpath = next((dyn_string(v) for t, v in dyn_entries if t == DT_RPATH), None)
        runpath = next((dyn_string(v) for t, v in dyn_entries if t == DT_RUNPATH), None)

        build_id = None
        for note_off, note_size in notes:
            cur, end = note_off, note_off + note_size
            while cur + 12 <= end:
                namesz, descsz, n_type = _unpack(endian + "III", data, cur)
                cur += 12
                name_start = cur
                name_end = name_start + namesz
                desc_start = (name_end + 3) & ~3
                desc_end = desc_start + descsz
                next_note = (desc_end + 3) & ~3
                if next_note > end or desc_end > len(data):
                    break
                name = data[name_start:name_end].rstrip(b"\0")
                desc = data[desc_start:desc_end]
                if name == b"GNU" and n_type == 3:
                    build_id = desc.hex()
                    break
                cur = next_note
            if build_id:
                break

        return {
            "is_elf": True,
            "class": ELF_CLASS[elf_class],
            "endianness": ELF_DATA[elf_data],
            "type": e_type,
            "machine": MACHINE_NAMES.get(e_machine, f"unknown ({e_machine})"),
            "machine_id": e_machine,
            "entry_point": hex(e_entry),
            "program_header_count": e_phnum,
            "section_header_count": e_shnum,
            "needed_libraries": [x for x in needed if x],
            "soname": soname,
            "rpath": rpath,
            "runpath": runpath,
            "gnu_build_id": build_id,
            "parse_notes": [],
        }
    except (ValueError, struct.error, OverflowError) as exc:
        return {"is_elf": False, "reason": f"ELF parse error: {exc}"}


def run_command(command: list[str], timeout: int = 30) -> dict[str, Any]:
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=timeout, check=False)
        stdout = result.stdout
        stderr = result.stderr
        output_limit = 60000
        return {
            "command": command,
            "returncode": result.returncode,
            "stdout": stdout[:output_limit],
            "stdout_truncated": len(stdout) > output_limit,
            "stderr": stderr[:output_limit],
            "stderr_truncated": len(stderr) > output_limit,
        }
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"command": command, "error": str(exc)}


def discover_readelf() -> str | None:
    for candidate in ("llvm-readelf", "readelf", "aarch64-linux-android-readelf"):
        found = shutil.which(candidate)
        if found:
            return found
    return None


def markdown_report(report: dict[str, Any]) -> str:
    lines = [
        "# Minecraft APK — Step 1 static inspection report",
        "",
        f"- Generated (UTC): `{report['generated_utc']}`",
        f"- APK: `{report['apk']['filename']}`",
        f"- APK size: `{report['apk']['size_bytes']:,}` bytes",
        f"- APK SHA-256: `{report['apk']['sha256']}`",
        f"- Detected package name: `{report.get('detected_package_name') or 'not decoded'}`",
        f"- Detected version name/code: `{report.get('detected_version_name') or 'not decoded'}` / `{report.get('detected_version_code') or 'not decoded'}`",
        "- Analysis type: **static only** (the APK was not installed, launched, modified, or attached to)",
        "",
        "## Package and version evidence",
        "",
    ]
    if report.get("android_tools"):
        for item in report["android_tools"]:
            lines.append(f"### `{Path(item['command'][0]).name}`")
            if item.get("stdout"):
                lines.extend(["", "```text", item["stdout"].rstrip(), "```"])
            if item.get("error"):
                lines.extend(["", f"Tool unavailable/error: `{item['error']}`"])
    else:
        lines.append("Android SDK tools (`apkanalyzer` / `aapt`) were not found. Package/version metadata was not decoded from the binary Android manifest.")
    lines.extend(["", "## ABI inventory", ""])
    if report["abis"]:
        for abi, count in report["abis"].items():
            lines.append(f"- `{abi}` ({ABI_NAMES.get(abi, 'unrecognized ABI')}): {count} native library file(s)")
    else:
        lines.append("No `lib/<abi>/*.so` entries were found.")
    lines.extend(["", "## Native libraries", ""])
    if not report["native_libraries"]:
        lines.append("No native `.so` files were found in the APK.")
    for lib in report["native_libraries"]:
        elf = lib["elf"]
        lines.append(f"### `{lib['path']}`")
        lines.append(f"- Size: {lib['size_bytes']:,} bytes; SHA-256: `{lib['sha256']}`")
        if lib.get("filename_hint"):
            lines.append(f"- Filename hint: {lib['filename_hint']}")
        if elf.get("is_elf"):
            lines.append(f"- ELF: {elf['class']}, {elf['endianness']}, {elf['machine']} (machine ID {elf['machine_id']})")
            lines.append(f"- SONAME: `{elf.get('soname') or '(not set)'}`")
            lines.append(f"- GNU build ID: `{elf.get('gnu_build_id') or '(not present)'}`")
            lines.append(f"- DT_NEEDED: {', '.join(f'`{x}`' for x in elf.get('needed_libraries', [])) or '(none parsed)'}")
            if elf.get("rpath") or elf.get("runpath"):
                lines.append(f"- RPATH/RUNPATH: `{elf.get('rpath') or elf.get('runpath')}`")
        else:
            lines.append(f"- ELF parsing: **not confirmed** — {elf.get('reason', 'unknown reason')}")
        if lib.get("readelf"):
            re = lib["readelf"]
            lines.append(f"- `readelf -h -d -Ws` return code: `{re.get('returncode', 'error')}` (full output in JSON report)")
        lines.append("")
    lines.extend([
        "## Other APK contents",
        "",
        f"- DEX files: {len(report['dex_files'])}",
        f"- Asset entries: {report['asset_entry_count']}",
        f"- Resource entries: {report['resource_entry_count']}",
        f"- Manifest entry present: {'yes' if report['manifest_present'] else 'no'}",
        "",
        "## Important interpretation limits",
        "",
        "1. A library named `libminecraftpe.so` is a strong indicator of the bundled game engine, but its filename alone does not prove it contains a client modification.",
        "2. `DT_NEEDED` lists ELF dynamic dependencies, not all libraries loaded later with `dlopen()`.",
        "3. Static APK inventory cannot prove runtime initialization, in-process loading, hook success, or module functionality.",
        "4. Stripped symbols and obfuscation can prevent reliable function identification. Do not invent offsets or infer private structures from names alone.",
        "5. Compare package/version metadata, hashes, ABI and ELF details with the exact installed Minecraft build before considering any integration work.",
        "",
        "## Next evidence needed",
        "",
        "- The exact Minecraft APK being targeted (preferably the original, unmodified APK).",
        "- `apkanalyzer` or `aapt` output for package name and version.",
        "- Native library inventory and ELF dependency output from this report.",
        "- If runtime initialization is being studied, a separate controlled runtime trace from a test device; this script does not perform runtime tracing.",
        "",
    ])
    return "\n".join(lines)


def inspect_apk(apk_path: Path, out_dir: Path, expected_version: str | None = None) -> dict[str, Any]:
    if not apk_path.is_file():
        raise FileNotFoundError(f"APK not found: {apk_path}")
    out_dir.mkdir(parents=True, exist_ok=True)
    all_entries: list[str] = []
    native_libraries: list[dict[str, Any]] = []
    dex_files: list[str] = []
    abis: dict[str, int] = {}
    asset_count = resource_count = 0
    manifest_present = False
    readelf_path = discover_readelf()

    with apk_path.open("rb") as apk_file:
        apk_hash = sha256_fileobj(apk_file)
    with zipfile.ZipFile(apk_path, "r") as zf:
        bad_member = zf.testzip()
        if bad_member:
            raise ValueError(f"APK ZIP integrity check failed at: {bad_member}")
        for info in zf.infolist():
            name = info.filename
            all_entries.append(name)
            if name == "AndroidManifest.xml":
                manifest_present = True
            if name.startswith("assets/"):
                asset_count += 1
            if name.startswith("res/"):
                resource_count += 1
            if name.startswith("classes") and name.endswith(".dex"):
                dex_files.append(name)
            if name.startswith("lib/") and name.endswith(".so"):
                parts = name.split("/")
                abi = parts[1] if len(parts) >= 3 else "unknown"
                abis[abi] = abis.get(abi, 0) + 1
                data = zf.read(info)
                parsed = parse_elf(data)
                lib_record: dict[str, Any] = {
                    "path": name,
                    "size_bytes": info.file_size,
                    "sha256": hashlib.sha256(data).hexdigest(),
                    "elf": parsed,
                }
                if readelf_path and parsed.get("is_elf"):
                    # Use readelf only for inspection; no code is executed from the APK.
                    # The file is written only to the audit output directory.
                    temp_path = out_dir / ".tmp-readelf.so"
                    temp_path.write_bytes(data)
                    lib_record["readelf"] = run_command([readelf_path, "-h", "-d", "-Ws", str(temp_path)], timeout=30)
                    try:
                        temp_path.unlink()
                    except OSError:
                        pass
                # Keep a copy for deeper, manual read-only inspection.
                destination = out_dir / "native-libraries" / abi / Path(name).name
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(data)
                lib_record["extracted_path"] = str(destination.relative_to(out_dir))
                native_libraries.append(lib_record)

    android_tools: list[dict[str, Any]] = []
    apkanalyzer = shutil.which("apkanalyzer")
    aapt = shutil.which("aapt")
    if apkanalyzer:
        android_tools.append(run_command([apkanalyzer, "manifest", "print", str(apk_path)]))
    if aapt:
        android_tools.append(run_command([aapt, "dump", "badging", str(apk_path)]))
    package_text = "\n".join(x.get("stdout", "") for x in android_tools)
    package_match = version_match = version_code_match = None
    if package_text:
        import re
        package_patterns = (
            r"package:\s+name=['\"]([^'\"]+)",
            r"<manifest[^>]*\bpackage=['\"]([^'\"]+)",
        )
        version_patterns = (
            r"versionName=['\"]([^'\"]+)",
            r"android:versionName=['\"]([^'\"]+)",
        )
        code_patterns = (
            r"versionCode=['\"]([^'\"]+)",
            r"android:versionCode=['\"]([^'\"]+)",
        )
        for pattern in package_patterns:
            match = re.search(pattern, package_text)
            if match:
                package_match = match.group(1)
                break
        for pattern in version_patterns:
            match = re.search(pattern, package_text)
            if match:
                version_match = match.group(1)
                break
        for pattern in code_patterns:
            match = re.search(pattern, package_text)
            if match:
                version_code_match = match.group(1)
                break
    version_check = "not_checked"
    if expected_version:
        version_check = "match" if version_match == expected_version else ("mismatch" if version_match else "unknown")

    report: dict[str, Any] = {
        "schema_version": 1,
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "apk": {"filename": apk_path.name, "absolute_path": str(apk_path.resolve()), "size_bytes": apk_path.stat().st_size, "sha256": apk_hash},
        "expected_version": expected_version,
        "detected_package_name": package_match,
        "detected_version_name": version_match,
        "detected_version_code": version_code_match,
        "version_check": version_check,
        "manifest_present": manifest_present,
        "abis": dict(sorted(abis.items())),
        "native_libraries": native_libraries,
        "dex_files": sorted(dex_files),
        "asset_entry_count": asset_count,
        "resource_entry_count": resource_count,
        "entry_count": len(all_entries),
        "entries": sorted(all_entries),
        "readelf_available": readelf_path,
        "android_tools": android_tools,
    }
    (out_dir / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (out_dir / "report.md").write_text(markdown_report(report), encoding="utf-8")
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Statically inspect an Android APK and its native ELF libraries.")
    parser.add_argument("apk", type=Path, help="path to the Minecraft APK to inspect")
    parser.add_argument("--out", type=Path, default=Path("artifacts/minecraft-apk-audit"), help="output directory (default: artifacts/minecraft-apk-audit)")
    parser.add_argument("--expected-version", default="1.26.60", help="versionName to compare against (default: 1.26.60); this is a comparison, not proof of identity")
    args = parser.parse_args()
    try:
        report = inspect_apk(args.apk, args.out, args.expected_version)
    except (OSError, ValueError, zipfile.BadZipFile) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    print(f"APK SHA-256: {report['apk']['sha256']}")
    print(f"ABI inventory: {report['abis'] or 'no native libraries found'}")
    print(f"Native libraries: {len(report['native_libraries'])}")
    print(f"Detected versionName: {report['detected_version_name'] or 'not decoded (install Android SDK build-tools)'}")
    print(f"Version check: {report['version_check']}")
    print(f"Reports: {args.out / 'report.md'} and {args.out / 'report.json'}")
    print("Note: static inspection only; no runtime integration or module functionality is proven.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
