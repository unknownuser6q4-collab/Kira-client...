# Step 5 — native module runtime

## Added

- `module_runtime.h/.cpp` connects `ModuleManager`, `WorldSnapshotReader`, and `FrameRenderer`.
- First executable module: `hitbox` entity-bounds visualization.
- Reads the module's enabled state from the native mirror; Kotlin remains authoritative for saved settings.
- Reads optional `hitbox.range` setting as a numeric block radius (default 64, clamped to 512).
- Filters out dead entities, zero runtime IDs, and entities outside the configured range.
- Queues validated 3D bounds and flushes them through the supplied render backend.
- Returns structured per-frame status and examined/rendered/rejected counts.
- `tests/module_runtime_smoke.cpp` and `scripts/test-module-runtime.sh` verify enabled/disabled behavior, range filtering, dead-entity filtering and renderer calls using fixtures.

## Scope and limitations

This is the first actual native module execution path, but it is not yet a working Bedrock cheat/client integration. The smoke test uses a fake world provider and fake rendering backend. No live Minecraft process, private symbols, offsets, injection path or renderer callback has been supplied or tested.

The current bridge reports generic entity records and has no verified player-type classification. Therefore `hitbox` draws bounds for alive entities generally; it must not be described as player-only ESP. The runtime does not alter player movement, attacks, inventory, blocks or world state. Other modules remain unimplemented beyond their GUI/config/native state mirrors.

A real provider for the exact Minecraft Bedrock 1.26.60 binary must register the verified callbacks from inside the game process and provide a render-thread callback before this module can draw in-game. Provider identity and callback capability checks remain mandatory.

## Verification

```bash
./scripts/test-native-bridge.sh
./scripts/test-render-pipeline.sh
./scripts/test-world-snapshot.sh
./scripts/test-module-runtime.sh
python3 -m unittest discover -s tests -v
```
