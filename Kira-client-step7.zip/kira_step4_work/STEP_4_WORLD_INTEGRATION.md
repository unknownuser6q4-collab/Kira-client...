# Step 4 — Player, entity and world data layer

## Added

- `world_snapshot.h/.cpp`: read-only snapshot builder over the version/build-verified `GameIntegration` facade.
- Player-state validation for finite position/rotation/health values.
- Entity-state validation for finite positions, ordered bounds and plausible health values.
- A hard cap of 512 entities per snapshot to bound memory and per-frame work. Excess provider entries are counted as rejected rather than read.
- Rejection counters for malformed or failed entity records.
- Squared-distance helper for sorting/range checks without a square root.
- Bounded block-coordinate query wrapper and provider result reporting.
- `tests/world_snapshot_smoke.cpp` and `scripts/test-world-snapshot.sh` using a fake provider.

## Current behavior and limitations

This is a data-consumption layer, not a Minecraft world reader by itself. It only receives player/entity/block data when an authorized, in-process provider registers callbacks for the exact game version and exact binary build ID. No provider for Minecraft Bedrock 1.26.60 is included, and no private symbols, offsets, memory layouts, or hooks are guessed.

The snapshot currently exposes raw entity IDs, positions, bounds, health, type IDs and alive flags. It does not infer entity names, teams, inventory, block categories, or visibility. ESP, storage detection, geode detection, aim targeting, and other gameplay modules are not implemented by this layer. A real provider and in-game validation are still required.

## Verification

Run:

```bash
./scripts/test-native-bridge.sh
./scripts/test-render-pipeline.sh
./scripts/test-world-snapshot.sh
python3 -m unittest discover -s tests -v
```

The world test exercises a fake provider only. Passing it verifies the client-side contract and validation logic, not Minecraft attachment.
