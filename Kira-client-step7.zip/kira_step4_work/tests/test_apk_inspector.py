import json
import struct
import tempfile
import unittest
import zipfile
from pathlib import Path

from tools.apk_inspector import inspect_apk, parse_elf


def minimal_elf64_aarch64():
    ident = b"\x7fELF" + bytes([2, 1, 1, 0]) + bytes(8)
    header = struct.pack(
        "<HHIQQQIHHHHHH",
        3, 183, 1, 0, 0, 0, 0,
        64, 56, 0, 64, 0, 0,
    )
    return ident + header


class ApkInspectorTests(unittest.TestCase):
    def test_parse_elf64_arm64(self):
        result = parse_elf(minimal_elf64_aarch64())
        self.assertTrue(result["is_elf"])
        self.assertEqual(result["class"], "ELF64")
        self.assertEqual(result["machine"], "EM_AARCH64 (ARM64)")

    def test_reject_non_elf(self):
        result = parse_elf(b"not an ELF library")
        self.assertFalse(result["is_elf"])

    def test_inspect_synthetic_apk(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            apk = root / "minecraft-test.apk"
            out = root / "audit"
            with zipfile.ZipFile(apk, "w") as zf:
                zf.writestr("AndroidManifest.xml", b"synthetic manifest")
                zf.writestr("classes.dex", b"dex placeholder")
                zf.writestr("lib/arm64-v8a/libminecraftpe.so", minimal_elf64_aarch64())
            report = inspect_apk(apk, out, "1.26.60")
            self.assertEqual(report["abis"], {"arm64-v8a": 1})
            self.assertEqual(len(report["native_libraries"]), 1)
            self.assertTrue((out / "report.md").is_file())
            saved = json.loads((out / "report.json").read_text())
            self.assertEqual(saved["native_libraries"][0]["elf"]["machine_id"], 183)


if __name__ == "__main__":
    unittest.main()
