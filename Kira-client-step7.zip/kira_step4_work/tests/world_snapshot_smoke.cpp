#include <cassert>
#include <cmath>
#include "game_bridge_api.h"
#include "game_integration.h"
#include "world_snapshot.h"

struct FakeWorld { uint32_t count = 3; };
static int player(void*, MoonlightPlayerStateV1* p) {
    if (!p) return 0;
    *p = {}; p->position = {10, 64, -4}; p->health = 20; p->alive = 1; return 1;
}
static int count(void* c, uint32_t* n) { if (!c || !n) return 0; *n = static_cast<FakeWorld*>(c)->count; return 1; }
static int entity(void*, uint32_t i, MoonlightEntityStateV1* e) {
    if (!e || i >= 3) return 0;
    *e = {}; e->runtime_id = i + 1; e->position = {float(i), 64, 0};
    e->bounds_min = {float(i)-0.3f, 63, -0.3f}; e->bounds_max = {float(i)+0.3f, 65, 0.3f};
    e->health = 20; e->alive = 1; return 1;
}
static int block(void*, int32_t x, int32_t y, int32_t z, uint32_t* id) {
    if (!id) return 0;
    *id = (x == 1 && y == 2 && z == 3) ? 42u : 0u; return 1;
}
int main() {
    FakeWorld ctx;
    MoonlightGameBridgeV1 b{}; b.abi_version = MOONLIGHT_GAME_BRIDGE_ABI;
    b.struct_size = sizeof(b); b.game_version = "1.26.60"; b.game_build_id = "fixture-build";
    b.context = &ctx; b.capabilities = MOONLIGHT_CAP_PLAYER_READ | MOONLIGHT_CAP_ENTITY_READ | MOONLIGHT_CAP_BLOCK_QUERY;
    b.get_player_state = player; b.get_entity_count = count; b.get_entity_state = entity; b.query_block = block;
    assert(moonlight_game_bridge_register_v1(&b));
    moonlight::integration::GameIntegration game("1.26.60", "fixture-build");
    assert(game.refresh() == moonlight::integration::Result::Ok);
    moonlight::world::WorldSnapshotReader reader(game);
    moonlight::world::Snapshot snap;
    assert(reader.capture(&snap) == moonlight::world::SnapshotResult::Ok);
    assert(snap.player.position.y == 64 && snap.entities.size() == 3);
    assert(snap.providerEntityCount == 3 && snap.rejectedEntityCount == 0);
    assert(std::fabs(moonlight::world::WorldSnapshotReader::distanceSquared(
        snap.player.position, snap.entities[0].position) - 116.0f) < 0.001f);
    auto q = reader.blockAt(1, 2, 3); assert(q.status == moonlight::integration::Result::Ok && q.blockId == 42);
    auto bad = reader.blockAt(30000001, 0, 0); assert(bad.status == moonlight::integration::Result::CallbackFailed);
    assert(reader.capture(nullptr) == moonlight::world::SnapshotResult::ProviderFailure);
    moonlight_game_bridge_unregister_v1();
}
