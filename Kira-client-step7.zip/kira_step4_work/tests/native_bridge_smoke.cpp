#include <cassert>
#include <cstring>
#include "module_manager.h"
#include "game_bridge_api.h"
#include "game_integration.h"

static int player(void*, MoonlightPlayerStateV1* out) {
    if (!out) return 0;
    *out = {};
    out->position.x = 12.0f;
    out->alive = 1;
    return 1;
}
static int entity_count(void*, uint32_t* out) { if (!out) return 0; *out = 0; return 1; }
static int entity_state(void*, uint32_t, MoonlightEntityStateV1* out) { if (!out) return 0; *out = {}; return 1; }
static int player_classify(void*, uint64_t id, uint8_t* out) { if (!out || id == 0) return 0; *out = 1; return 1; }
static int input_state(void*, MoonlightInputStateV1* out) { if (!out) return 0; *out = {}; out->forward = 1.0f; return 1; }

int main() {
    moonlight::ModuleManager manager;
    assert(manager.add("freecam"));
    assert(manager.setEnabled("freecam", true));
    assert(manager.enabled("freecam"));
    assert(manager.setSetting("freecam", "speed", "2.5"));
    assert(manager.setting("freecam", "speed") == "2.5");
    manager.clearSettings();
    assert(manager.setting("freecam", "speed").empty());

    MoonlightGameBridgeV1 bridge{};
    bridge.abi_version = MOONLIGHT_GAME_BRIDGE_ABI;
    bridge.struct_size = sizeof(bridge);
    bridge.game_version = "1.26.60";
    bridge.game_build_id = "test-sha256-build-id";
    bridge.capabilities = MOONLIGHT_CAP_PLAYER_READ | MOONLIGHT_CAP_ENTITY_READ |
                          MOONLIGHT_CAP_CAMERA_CONTROL | MOONLIGHT_CAP_INPUT_READ |
                          MOONLIGHT_CAP_PLAYER_CLASSIFY;
    bridge.get_player_state = player;
    bridge.get_entity_count = entity_count;
    bridge.get_entity_state = entity_state;
    bridge.get_input_state = input_state;
    bridge.is_player_entity = player_classify;
    // Camera capability is advertised without its callback and must be stripped.
    assert(moonlight_game_bridge_register_v1(&bridge) == 1);

    MoonlightBridgeStatusV1 status{};
    assert(moonlight_game_bridge_status_v1(&status) == 1);
    assert(status.attached == 1);
    assert(status.abi_version == MOONLIGHT_GAME_BRIDGE_ABI);
    assert(std::strcmp(status.game_version, "1.26.60") == 0);
    assert((status.capabilities & MOONLIGHT_CAP_PLAYER_READ) != 0);
    assert((status.capabilities & MOONLIGHT_CAP_ENTITY_READ) != 0);
    assert((status.capabilities & MOONLIGHT_CAP_CAMERA_CONTROL) == 0);
    assert((status.capabilities & MOONLIGHT_CAP_INPUT_READ) != 0);
    assert((status.capabilities & MOONLIGHT_CAP_PLAYER_CLASSIFY) != 0);

    moonlight::integration::GameIntegration integration("1.26.60", "test-sha256-build-id");
    assert(integration.refresh() == moonlight::integration::Result::Ok);
    assert(integration.ready());
    MoonlightPlayerStateV1 playerState{};
    assert(integration.readPlayer(&playerState) == moonlight::integration::Result::Ok);
    assert(playerState.position.x == 12.0f);
    MoonlightInputStateV1 input{};
    assert(integration.readInput(&input) == moonlight::integration::Result::Ok);
    assert(input.forward == 1.0f);
    bool isPlayer = false;
    assert(integration.isPlayerEntity(7, &isPlayer) == moonlight::integration::Result::Ok);
    assert(isPlayer);
    assert(integration.setCamera({}, 0.0f, 0.0f) ==
           moonlight::integration::Result::CapabilityMissing);

    moonlight::integration::GameIntegration wrongBuild("1.26.60", "different-build");
    assert(wrongBuild.refresh() == moonlight::integration::Result::BuildMismatch);
    assert(!wrongBuild.ready());

    moonlight_game_bridge_unregister_v1();
    assert(moonlight_game_bridge_status_v1(&status) == 1 && status.attached == 0);
    assert(integration.refresh() == moonlight::integration::Result::Detached);
}
