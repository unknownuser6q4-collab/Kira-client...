#include "render_pipeline.h"
#include "game_bridge_api.h"

#include <cassert>
#include <cmath>
#include <cstdint>
#include <string>
#include <vector>

using moonlight::render::Backend;
using moonlight::render::FrameRenderer;
using moonlight::render::FrameResult;
using moonlight::render::Viewport;

class FakeBackend final : public Backend {
public:
    bool allowBegin = true;
    bool allowCommands = true;
    bool allowEnd = true;
    bool began = false;
    bool ended = false;
    Viewport lastViewport{};
    int lineCount = 0;
    int textCount = 0;
    int boxCount = 0;
    std::vector<std::string> texts;

    bool beginFrame(const Viewport& viewport) override {
        began = allowBegin;
        lastViewport = viewport;
        return allowBegin;
    }
    bool line2D(float, float, float, float, uint32_t) override {
        if (!allowCommands) return false;
        ++lineCount;
        return true;
    }
    bool text2D(float, float, const std::string& text, uint32_t) override {
        if (!allowCommands) return false;
        ++textCount;
        texts.push_back(text);
        return true;
    }
    bool box3D(const MoonlightVec3V1&, const MoonlightVec3V1&, uint32_t) override {
        if (!allowCommands) return false;
        ++boxCount;
        return true;
    }
    bool endFrame() override {
        ended = allowEnd;
        return allowEnd;
    }
};

static int providerLineCount = 0;
static int providerTextCount = 0;
static int providerBoxCount = 0;
static int providerDrawLine(void*, float, float, float, float, uint32_t) {
    ++providerLineCount;
    return 1;
}
static int providerDrawText(void*, float, float, const char*, uint32_t) {
    ++providerTextCount;
    return 1;
}
static int providerDrawBox(void*, const MoonlightVec3V1*, const MoonlightVec3V1*, uint32_t) {
    ++providerBoxCount;
    return 1;
}

int main() {
    FrameRenderer renderer;
    FakeBackend backend;

    assert(renderer.line2D(0, 0, 1, 1, 0xFFFFFFFFu) == FrameResult::NoActiveFrame);
    assert(renderer.beginFrame({0, 720, 1}) == FrameResult::InvalidViewport);
    assert(renderer.beginFrame({1280, 720, 1}) == FrameResult::Ok);
    assert(renderer.beginFrame({1280, 720, 2}) == FrameResult::FrameAlreadyActive);
    assert(renderer.line2D(1, 2, 3, 4, 0xFF00FFFFu) == FrameResult::Ok);
    assert(renderer.outlineRect2D(10, 20, 40, 60, 0xFFFFFFFFu) == FrameResult::Ok);
    assert(renderer.text2D(12, 24, "ESP label", 0xFFFFFFFFu) == FrameResult::Ok);
    const MoonlightVec3V1 min{1, 2, 3};
    const MoonlightVec3V1 max{4, 5, 6};
    assert(renderer.box3D(min, max, 0x00FF00FFu) == FrameResult::Ok);
    assert(renderer.box3D(max, min, 0x00FF00FFu) == FrameResult::InvalidCommand);
    assert(renderer.line2D(NAN, 0, 1, 1, 0) == FrameResult::InvalidCommand);
    assert(renderer.queuedCommandCount() == 7);

    assert(renderer.flush(backend) == FrameResult::Ok);
    assert(backend.began && backend.ended);
    assert(backend.lastViewport.width == 1280 && backend.lastViewport.height == 720);
    assert(backend.lastViewport.frameId == 1);
    assert(backend.lineCount == 5); // one line + four rectangle edges
    assert(backend.textCount == 1 && backend.texts.front() == "ESP label");
    assert(backend.boxCount == 1);
    assert(renderer.queuedCommandCount() == 0);
    assert(renderer.lastCompletedFrameId() == 1);
    assert(renderer.beginFrame({1280, 720, 1}) == FrameResult::StaleFrame);

    assert(renderer.beginFrame({1280, 720, 2}) == FrameResult::Ok);
    assert(renderer.line2D(1, 1, 2, 2, 0xFFFFFFFFu) == FrameResult::Ok);
    backend.allowBegin = false;
    assert(renderer.flush(backend) == FrameResult::BackendUnavailable);
    backend.allowBegin = true;

    assert(renderer.beginFrame({1280, 720, 3}) == FrameResult::Ok);
    assert(renderer.line2D(1, 1, 2, 2, 0xFFFFFFFFu) == FrameResult::Ok);
    backend.allowCommands = false;
    assert(renderer.flush(backend) == FrameResult::CommandFailed);
    assert(backend.ended);
    backend.allowCommands = true;

    assert(renderer.beginFrame({1280, 720, 4}) == FrameResult::Ok);
    for (std::size_t i = 0; i < moonlight::render::kMaxFrameCommands; ++i) {
        assert(renderer.line2D(0, 0, 1, 1, 0xFFFFFFFFu) == FrameResult::Ok);
    }
    assert(renderer.line2D(0, 0, 1, 1, 0xFFFFFFFFu) == FrameResult::QueueFull);
    assert(renderer.outlineRect2D(0, 0, 2, 2, 0xFFFFFFFFu) == FrameResult::QueueFull);
    renderer.cancelFrame();
    assert(renderer.queuedCommandCount() == 0);

    // Verify that the concrete adapter delegates to version/build-gated provider callbacks.
    MoonlightGameBridgeV1 bridge{};
    bridge.abi_version = MOONLIGHT_GAME_BRIDGE_ABI;
    bridge.struct_size = sizeof(bridge);
    bridge.game_version = "1.26.60";
    bridge.game_build_id = "render-test-build";
    bridge.capabilities = MOONLIGHT_CAP_OVERLAY_2D | MOONLIGHT_CAP_OVERLAY_3D;
    bridge.draw_line_2d = providerDrawLine;
    bridge.draw_text_2d = providerDrawText;
    bridge.draw_box_3d = providerDrawBox;
    assert(moonlight_game_bridge_register_v1(&bridge) == 1);

    moonlight::integration::GameIntegration game("1.26.60", "render-test-build");
    assert(game.refresh() == moonlight::integration::Result::Ok);
    moonlight::render::GameBridgeBackend gameBackend(game);
    assert(gameBackend.beginFrame({1920, 1080, 10}));
    assert(gameBackend.line2D(0, 0, 100, 100, 0xFFFFFFFFu));
    assert(gameBackend.text2D(10, 10, "provider", 0xFFFFFFFFu));
    assert(gameBackend.box3D(min, max, 0xFFFFFFFFu));
    assert(gameBackend.endFrame());
    assert(providerLineCount == 1 && providerTextCount == 1 && providerBoxCount == 1);

    moonlight_game_bridge_unregister_v1();
    assert(!gameBackend.beginFrame({1920, 1080, 11}));
    return 0;
}
