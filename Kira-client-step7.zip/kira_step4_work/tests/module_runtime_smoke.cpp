#include "game_bridge_api.h"
#include "game_integration.h"
#include "module_manager.h"
#include "module_runtime.h"

#include <cassert>
#include <cstring>
#include <string>

struct Fixture {};
static int player(void*, MoonlightPlayerStateV1* p) {
    if (!p) return 0;
    *p = {}; p->position = {0, 64, 0}; p->health = 20; p->alive = 1; return 1;
}
static int count(void*, uint32_t* n) { if (!n) return 0; *n = 3; return 1; }
static int entity(void*, uint32_t i, MoonlightEntityStateV1* e) {
    if (!e || i >= 3) return 0;
    *e = {}; e->runtime_id = i + 1; e->position = {float(i + 1), 64, 0};
    e->bounds_min = {float(i + 1) - .3f, 63, -.3f};
    e->bounds_max = {float(i + 1) + .3f, 65, .3f};
    e->health = 20; e->alive = i == 2 ? 0 : 1; return 1;
}
static int classifyPlayer(void*, uint64_t runtimeId, uint8_t* out) {
    if (!out || runtimeId == 0 || runtimeId > 3) return 0;
    *out = runtimeId == 1 ? 1 : 0;
    return 1;
}
static int project(void*, const MoonlightVec3V1* world, int32_t width, int32_t height,
                   MoonlightScreenPointV1* out) {
    if (!world || !out || width <= 0 || height <= 0) return 0;
    *out = {}; out->x = width * 0.5f + world->x * 10.0f;
    out->y = height * 0.5f - world->y; out->visible = 1; return 1;
}
static int entityName(void*, uint64_t runtimeId, char* out, uint32_t capacity) {
    if (!out || capacity < 2 || runtimeId == 0 || runtimeId > 3) return 0;
    const char* value = runtimeId == 1 ? "TestPlayer" : "OtherEntity";
    std::strncpy(out, value, capacity - 1); out[capacity - 1] = '\0'; return 1;
}
class FakeBackend final : public moonlight::render::Backend {
public:
    int boxes = 0; int lines = 0; int texts = 0; bool open = false;
    bool beginFrame(const moonlight::render::Viewport&) override { open = true; return true; }
    bool line2D(float, float, float, float, uint32_t) override { if (open) ++lines; return open; }
    bool text2D(float, float, const std::string&, uint32_t) override { if (open) ++texts; return open; }
    bool box3D(const MoonlightVec3V1&, const MoonlightVec3V1&, uint32_t) override {
        if (!open) return false;
        ++boxes;
        return true;
    }
    bool endFrame() override { const bool wasOpen = open; open = false; return wasOpen; }
};
int main() {
    Fixture fixture;
    MoonlightGameBridgeV1 b{}; b.abi_version = MOONLIGHT_GAME_BRIDGE_ABI;
    b.struct_size = sizeof(b); b.game_version = "1.26.60"; b.game_build_id = "runtime-test";
    b.context = &fixture; b.capabilities = MOONLIGHT_CAP_PLAYER_READ | MOONLIGHT_CAP_ENTITY_READ |
                     MOONLIGHT_CAP_PLAYER_CLASSIFY | MOONLIGHT_CAP_WORLD_TO_SCREEN |
                     MOONLIGHT_CAP_ENTITY_NAME;
    b.get_player_state = player; b.get_entity_count = count; b.get_entity_state = entity;
    b.is_player_entity = classifyPlayer; b.project_world_to_screen = project;
    b.get_entity_name = entityName;
    assert(moonlight_game_bridge_register_v1(&b));

    moonlight::integration::GameIntegration game("1.26.60", "runtime-test");
    assert(game.refresh() == moonlight::integration::Result::Ok);
    moonlight::world::WorldSnapshotReader world(game);
    moonlight::ModuleManager manager;
    manager.setEnabled("hitbox", true);
    manager.setSetting("hitbox", "range", "8");
    moonlight::render::FrameRenderer renderer;
    moonlight::modules::ModuleRuntime runtime(manager, world, renderer);
    FakeBackend backend;

    auto result = runtime.runFrame({1280, 720, 1}, backend);
    assert(result.result == moonlight::modules::RunResult::Rendered);
    assert(result.examined == 3 && result.rendered == 2 && result.rejected == 1);
    assert(backend.boxes == 2 && !backend.open);

    manager.setEnabled("player_esp", true);
    manager.setSetting("player_esp", "range", "8");
    result = runtime.runPlayerEspFrame({1280, 720, 3}, backend);
    assert(result.result == moonlight::modules::RunResult::Rendered);
    assert(result.examined == 3 && result.rendered == 1 && result.rejected == 2);
    assert(backend.boxes == 3 && !backend.open);

    manager.setSetting("player_esp", "tracers", "true");
    manager.setSetting("player_esp", "names", "true");
    manager.setSetting("player_esp", "distance", "true");
    result = runtime.runPlayerEspDetailsFrame({1280, 720, 5}, backend);
    assert(result.result == moonlight::modules::RunResult::Rendered);
    assert(result.rendered == 1 && result.tracers == 1 && result.labels == 1);
    assert(backend.boxes == 4 && backend.lines == 1 && backend.texts == 1 && !backend.open);

    // A provider without the classifier must fail closed instead of drawing generic entities.
    MoonlightGameBridgeV1 noClassifier = b;
    noClassifier.is_player_entity = nullptr;
    assert(moonlight_game_bridge_register_v1(&noClassifier));
    assert(game.refresh() == moonlight::integration::Result::Ok);
    result = runtime.runPlayerEspFrame({1280, 720, 6}, backend);
    assert(result.result == moonlight::modules::RunResult::ClassificationUnavailable);
    assert(backend.boxes == 4 && !backend.open);

    manager.setEnabled("hitbox", false);
    result = runtime.runFrame({1280, 720, 7}, backend);
    assert(result.result == moonlight::modules::RunResult::ModuleDisabled);
    assert(backend.boxes == 4);
    moonlight_game_bridge_unregister_v1();
}
