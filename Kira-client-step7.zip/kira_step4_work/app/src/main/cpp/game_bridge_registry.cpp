#include "game_bridge_api.h"

#include <algorithm>
#include <cstring>
#include <mutex>

namespace {
std::mutex g_mutex;
MoonlightGameBridgeV1 g_bridge{};
bool g_attached = false;
char g_game_version[64]{};
char g_game_build_id[96]{};

}  // namespace

extern "C" {

int moonlight_game_bridge_register_v1(const MoonlightGameBridgeV1* bridge) {
    if (bridge == nullptr || bridge->abi_version != MOONLIGHT_GAME_BRIDGE_ABI) return 0;
    if (bridge->struct_size < sizeof(MoonlightGameBridgeV1)) return 0;

    // Capabilities may only be advertised when their required callback exists.
    uint64_t verified = bridge->capabilities;
    if (bridge->get_player_state == nullptr) verified &= ~MOONLIGHT_CAP_PLAYER_READ;
    if (bridge->get_entity_count == nullptr || bridge->get_entity_state == nullptr)
        verified &= ~MOONLIGHT_CAP_ENTITY_READ;
    if (bridge->get_input_state == nullptr) verified &= ~MOONLIGHT_CAP_INPUT_READ;
    if (bridge->set_camera == nullptr) verified &= ~MOONLIGHT_CAP_CAMERA_CONTROL;
    if (bridge->set_player_motion == nullptr || bridge->set_player_flag == nullptr)
        verified &= ~MOONLIGHT_CAP_PLAYER_CONTROL;
    if (bridge->set_world_brightness == nullptr) verified &= ~MOONLIGHT_CAP_WORLD_LIGHTING;
    if (bridge->draw_line_2d == nullptr || bridge->draw_text_2d == nullptr)
        verified &= ~MOONLIGHT_CAP_OVERLAY_2D;
    if (bridge->draw_box_3d == nullptr) verified &= ~MOONLIGHT_CAP_OVERLAY_3D;
    if (bridge->query_block == nullptr) verified &= ~MOONLIGHT_CAP_BLOCK_QUERY;
    if (bridge->is_player_entity == nullptr) verified &= ~MOONLIGHT_CAP_PLAYER_CLASSIFY;
    if (bridge->project_world_to_screen == nullptr) verified &= ~MOONLIGHT_CAP_WORLD_TO_SCREEN;
    if (bridge->get_entity_name == nullptr) verified &= ~MOONLIGHT_CAP_ENTITY_NAME;

    std::lock_guard<std::mutex> lock(g_mutex);
    g_bridge = *bridge;
    g_bridge.capabilities = verified;
    g_game_version[0] = '\0';
    g_game_build_id[0] = '\0';
    if (bridge->game_version != nullptr) {
        std::strncpy(g_game_version, bridge->game_version, sizeof(g_game_version) - 1);
        g_game_version[sizeof(g_game_version) - 1] = '\0';
    }
    g_bridge.game_version = g_game_version;
    if (bridge->game_build_id != nullptr) {
        std::strncpy(g_game_build_id, bridge->game_build_id, sizeof(g_game_build_id) - 1);
        g_game_build_id[sizeof(g_game_build_id) - 1] = '\0';
    }
    g_bridge.game_build_id = g_game_build_id;
    g_attached = true;
    return 1;
}

void moonlight_game_bridge_unregister_v1(void) {
    std::lock_guard<std::mutex> lock(g_mutex);
    g_bridge = {};
    g_game_version[0] = '\0';
    g_game_build_id[0] = '\0';
    g_attached = false;
}

int moonlight_game_bridge_get_v1(MoonlightGameBridgeV1* out_bridge) {
    if (out_bridge == nullptr) return 0;
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_attached) return 0;
    *out_bridge = g_bridge;
    out_bridge->game_version = g_game_version;
    out_bridge->game_build_id = g_game_build_id;
    return 1;
}

int moonlight_game_bridge_status_v1(MoonlightBridgeStatusV1* out_status) {
    if (out_status == nullptr) return 0;
    std::lock_guard<std::mutex> lock(g_mutex);
    *out_status = {};
    out_status->abi_version = MOONLIGHT_GAME_BRIDGE_ABI;
    out_status->attached = g_attached ? 1u : 0u;
    out_status->capabilities = g_attached ? g_bridge.capabilities : 0ull;
    std::strncpy(out_status->game_version, g_game_version, sizeof(out_status->game_version) - 1);
    return 1;
}

}  // extern "C"
