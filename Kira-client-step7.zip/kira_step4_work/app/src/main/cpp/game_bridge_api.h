#pragma once

/*
 * Stable C ABI contract between an in-process Bedrock integration provider and
 * Moonlight's native client. This header does NOT implement Minecraft hooks,
 * resolve private symbols, or grant access to the game. A provider built for the
 * exact target version must supply and validate every callback it advertises.
 */
#include <stdint.h>

#if defined(__GNUC__)
#define MOONLIGHT_BRIDGE_EXPORT __attribute__((visibility("default")))
#else
#define MOONLIGHT_BRIDGE_EXPORT
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define MOONLIGHT_GAME_BRIDGE_ABI 4u

enum MoonlightBridgeCapabilityV1 {
    MOONLIGHT_CAP_PLAYER_READ       = 1ull << 0,
    MOONLIGHT_CAP_ENTITY_READ       = 1ull << 1,
    MOONLIGHT_CAP_CAMERA_CONTROL    = 1ull << 2,
    MOONLIGHT_CAP_PLAYER_CONTROL    = 1ull << 3,
    MOONLIGHT_CAP_WORLD_LIGHTING    = 1ull << 4,
    MOONLIGHT_CAP_OVERLAY_2D        = 1ull << 5,
    MOONLIGHT_CAP_OVERLAY_3D        = 1ull << 6,
    MOONLIGHT_CAP_BLOCK_QUERY       = 1ull << 7,
    MOONLIGHT_CAP_INPUT_READ        = 1ull << 8,
    MOONLIGHT_CAP_PLAYER_CLASSIFY   = 1ull << 9,
    MOONLIGHT_CAP_WORLD_TO_SCREEN   = 1ull << 10,
    MOONLIGHT_CAP_ENTITY_NAME       = 1ull << 11
};

typedef struct MoonlightVec3V1 {
    float x, y, z;
} MoonlightVec3V1;

typedef struct MoonlightPlayerStateV1 {
    MoonlightVec3V1 position;
    float yaw;
    float pitch;
    float health;
    uint8_t on_ground;
    uint8_t alive;
    uint8_t reserved[2];
} MoonlightPlayerStateV1;

typedef struct MoonlightInputStateV1 {
    float forward;
    float strafe;
    float look_x;
    float look_y;
    uint32_t buttons;
} MoonlightInputStateV1;

typedef struct MoonlightScreenPointV1 {
    float x, y;
    uint8_t visible;
    uint8_t reserved[3];
} MoonlightScreenPointV1;

typedef struct MoonlightEntityStateV1 {
    uint64_t runtime_id;
    MoonlightVec3V1 position;
    MoonlightVec3V1 bounds_min;
    MoonlightVec3V1 bounds_max;
    float health;
    uint32_t type_id;
    uint8_t alive;
    uint8_t reserved[3];
} MoonlightEntityStateV1;

typedef struct MoonlightGameBridgeV1 {
    uint32_t abi_version;
    uint32_t struct_size;
    const char* game_version;
    const char* game_build_id; /* Exact target binary fingerprint supplied by provider. */
    uint64_t capabilities;
    void* context;

    int (*get_player_state)(void* context, MoonlightPlayerStateV1* out_state);
    int (*get_entity_count)(void* context, uint32_t* out_count);
    int (*get_entity_state)(void* context, uint32_t index, MoonlightEntityStateV1* out_state);
    int (*get_input_state)(void* context, MoonlightInputStateV1* out_state);
    int (*set_camera)(void* context, const MoonlightVec3V1* position, float yaw, float pitch);
    int (*set_player_motion)(void* context, const MoonlightVec3V1* velocity);
    int (*set_player_flag)(void* context, uint32_t flag, int enabled);
    int (*set_world_brightness)(void* context, float multiplier);
    /* 2D coordinates are pixel positions in the provider's documented viewport space. */
    int (*draw_line_2d)(void* context, float x1, float y1, float x2, float y2, uint32_t rgba);
    /* 3D bounds are world-space coordinates interpreted by the provider's renderer. */
    int (*draw_box_3d)(void* context, const MoonlightVec3V1* min, const MoonlightVec3V1* max, uint32_t rgba);
    int (*draw_text_2d)(void* context, float x, float y, const char* text, uint32_t rgba);
    int (*query_block)(void* context, int32_t x, int32_t y, int32_t z, uint32_t* out_block_id);
    /* Returns success and writes 1 only for a verified player entity. */
    int (*is_player_entity)(void* context, uint64_t runtime_id, uint8_t* out_is_player);
    /* Projection must use the same viewport coordinate space as draw_line_2d/draw_text_2d. */
    int (*project_world_to_screen)(void* context, const MoonlightVec3V1* world,
                                   int32_t viewport_width, int32_t viewport_height,
                                   MoonlightScreenPointV1* out_point);
    /* Writes a NUL-terminated UTF-8 name, truncating to out_capacity when needed. */
    int (*get_entity_name)(void* context, uint64_t runtime_id, char* out_name,
                           uint32_t out_capacity);
} MoonlightGameBridgeV1;

typedef struct MoonlightBridgeStatusV1 {
    uint32_t abi_version;
    uint32_t attached;
    uint64_t capabilities;
    char game_version[64];
} MoonlightBridgeStatusV1;

/* Register/unregister must be called by code executing inside the game process. */
MOONLIGHT_BRIDGE_EXPORT int moonlight_game_bridge_register_v1(const MoonlightGameBridgeV1* bridge);
MOONLIGHT_BRIDGE_EXPORT void moonlight_game_bridge_unregister_v1(void);
MOONLIGHT_BRIDGE_EXPORT int moonlight_game_bridge_status_v1(MoonlightBridgeStatusV1* out_status);
MOONLIGHT_BRIDGE_EXPORT int moonlight_game_bridge_get_v1(MoonlightGameBridgeV1* out_bridge);

#ifdef __cplusplus
}
#endif
