#include "render_pipeline.h"

#include <cmath>
#include <utility>

namespace moonlight::render {

GameBridgeBackend::GameBridgeBackend(integration::GameIntegration& game) : game_(game) {}

bool GameBridgeBackend::beginFrame(const Viewport& viewport) {
    frameOpen_ = false;
    if (viewport.width <= 0 || viewport.height <= 0 ||
        game_.refresh() != integration::Result::Ok || !game_.ready()) return false;
    frameOpen_ = true;
    return true;
}

bool GameBridgeBackend::line2D(float x1, float y1, float x2, float y2, uint32_t rgba) {
    return frameOpen_ && game_.drawLine2D(x1, y1, x2, y2, rgba) == integration::Result::Ok;
}

bool GameBridgeBackend::text2D(float x, float y, const std::string& text, uint32_t rgba) {
    return frameOpen_ && game_.drawText2D(x, y, text.c_str(), rgba) == integration::Result::Ok;
}

bool GameBridgeBackend::box3D(const MoonlightVec3V1& min, const MoonlightVec3V1& max,
                              uint32_t rgba) {
    return frameOpen_ && game_.drawBox3D(min, max, rgba) == integration::Result::Ok;
}

bool GameBridgeBackend::endFrame() {
    if (!frameOpen_) return false;
    frameOpen_ = false;
    return true;
}

bool FrameRenderer::finite(float value) {
    return std::isfinite(value);
}

FrameResult FrameRenderer::beginFrame(const Viewport& viewport) {
    if (viewport.width <= 0 || viewport.height <= 0 || viewport.width > 16384 ||
        viewport.height > 16384 || viewport.frameId == 0) {
        return FrameResult::InvalidViewport;
    }
    std::lock_guard<std::mutex> lock(mutex_);
    if (active_) return FrameResult::FrameAlreadyActive;
    if (viewport.frameId <= lastCompletedFrameId_) return FrameResult::StaleFrame;
    viewport_ = viewport;
    commands_.clear();
    active_ = true;
    return FrameResult::Ok;
}

FrameResult FrameRenderer::append(Command&& command) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!active_) return FrameResult::NoActiveFrame;
    if (commands_.size() >= kMaxFrameCommands) return FrameResult::QueueFull;
    commands_.push_back(std::move(command));
    return FrameResult::Ok;
}

FrameResult FrameRenderer::line2D(float x1, float y1, float x2, float y2, uint32_t rgba) {
    if (!finite(x1) || !finite(y1) || !finite(x2) || !finite(y2))
        return FrameResult::InvalidCommand;
    Command command;
    command.type = CommandType::Line2D;
    command.values[0] = x1;
    command.values[1] = y1;
    command.values[2] = x2;
    command.values[3] = y2;
    command.rgba = rgba;
    return append(std::move(command));
}

FrameResult FrameRenderer::outlineRect2D(float left, float top, float right, float bottom,
                                         uint32_t rgba) {
    if (!finite(left) || !finite(top) || !finite(right) || !finite(bottom) ||
        right <= left || bottom <= top) {
        return FrameResult::InvalidCommand;
    }

    std::lock_guard<std::mutex> lock(mutex_);
    if (!active_) return FrameResult::NoActiveFrame;
    if (commands_.size() > kMaxFrameCommands - 4) return FrameResult::QueueFull;

    const float lines[4][4] = {
            {left, top, right, top},
            {right, top, right, bottom},
            {right, bottom, left, bottom},
            {left, bottom, left, top},
    };
    for (const auto& line : lines) {
        Command command;
        command.type = CommandType::Line2D;
        for (int i = 0; i < 4; ++i) command.values[i] = line[i];
        command.rgba = rgba;
        commands_.push_back(std::move(command));
    }
    return FrameResult::Ok;
}

FrameResult FrameRenderer::text2D(float x, float y, const std::string& text, uint32_t rgba) {
    if (!finite(x) || !finite(y) || text.empty() || text.size() > kMaxTextBytes ||
        text.find('\0') != std::string::npos) {
        return FrameResult::InvalidCommand;
    }
    Command command;
    command.type = CommandType::Text2D;
    command.values[0] = x;
    command.values[1] = y;
    command.rgba = rgba;
    command.text = text;
    return append(std::move(command));
}

FrameResult FrameRenderer::box3D(const MoonlightVec3V1& min, const MoonlightVec3V1& max,
                                 uint32_t rgba) {
    if (!finite(min.x) || !finite(min.y) || !finite(min.z) || !finite(max.x) ||
        !finite(max.y) || !finite(max.z) || min.x > max.x || min.y > max.y || min.z > max.z) {
        return FrameResult::InvalidCommand;
    }
    Command command;
    command.type = CommandType::Box3D;
    command.min = min;
    command.max = max;
    command.rgba = rgba;
    return append(std::move(command));
}

FrameResult FrameRenderer::flush(Backend& backend) {
    std::vector<Command> commands;
    Viewport viewport;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (!active_) return FrameResult::NoActiveFrame;
        active_ = false;
        viewport = viewport_;
        commands.swap(commands_);
        lastCompletedFrameId_ = viewport.frameId;
    }

    if (!backend.beginFrame(viewport)) return FrameResult::BackendUnavailable;

    FrameResult result = FrameResult::Ok;
    for (const auto& command : commands) {
        bool ok = false;
        switch (command.type) {
            case CommandType::Line2D:
                ok = backend.line2D(command.values[0], command.values[1], command.values[2],
                                    command.values[3], command.rgba);
                break;
            case CommandType::Text2D:
                ok = backend.text2D(command.values[0], command.values[1], command.text,
                                    command.rgba);
                break;
            case CommandType::Box3D:
                ok = backend.box3D(command.min, command.max, command.rgba);
                break;
        }
        if (!ok) {
            result = FrameResult::CommandFailed;
            break;
        }
    }

    if (!backend.endFrame() && result == FrameResult::Ok) {
        result = FrameResult::BackendEndFailed;
    }
    return result;
}

void FrameRenderer::cancelFrame() {
    std::lock_guard<std::mutex> lock(mutex_);
    active_ = false;
    commands_.clear();
}

std::size_t FrameRenderer::queuedCommandCount() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return commands_.size();
}

uint64_t FrameRenderer::lastCompletedFrameId() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return lastCompletedFrameId_;
}

}  // namespace moonlight::render
