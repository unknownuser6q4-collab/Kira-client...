#pragma once

#include "game_integration.h"

#include <cstddef>
#include <cstdint>
#include <mutex>
#include <string>
#include <vector>

namespace moonlight::render {

constexpr std::size_t kMaxFrameCommands = 2048;
constexpr std::size_t kMaxTextBytes = 512;

struct Viewport {
    int32_t width = 0;
    int32_t height = 0;
    uint64_t frameId = 0;
};

enum class FrameResult {
    Ok = 0,
    InvalidViewport,
    FrameAlreadyActive,
    NoActiveFrame,
    StaleFrame,
    QueueFull,
    InvalidCommand,
    BackendUnavailable,
    BackendBeginFailed,
    CommandFailed,
    BackendEndFailed,
};

/**
 * Rendering backend contract. flush() must be called by the host's render callback
 * on the same thread/context that owns the renderer. Implementations must not retain
 * references to command data after a draw method returns.
 */
class Backend {
public:
    virtual ~Backend() = default;
    virtual bool beginFrame(const Viewport& viewport) = 0;
    virtual bool line2D(float x1, float y1, float x2, float y2, uint32_t rgba) = 0;
    virtual bool text2D(float x, float y, const std::string& text, uint32_t rgba) = 0;
    virtual bool box3D(const MoonlightVec3V1& min, const MoonlightVec3V1& max,
                       uint32_t rgba) = 0;
    virtual bool endFrame() = 0;
};

/** Adapter to the version/build-verified game provider's rendering callbacks. */
class GameBridgeBackend final : public Backend {
public:
    explicit GameBridgeBackend(integration::GameIntegration& game);

    bool beginFrame(const Viewport& viewport) override;
    bool line2D(float x1, float y1, float x2, float y2, uint32_t rgba) override;
    bool text2D(float x, float y, const std::string& text, uint32_t rgba) override;
    bool box3D(const MoonlightVec3V1& min, const MoonlightVec3V1& max,
               uint32_t rgba) override;
    bool endFrame() override;

private:
    integration::GameIntegration& game_;
    bool frameOpen_ = false;
};

/**
 * Thread-safe frame command queue. Producers may enqueue from module callbacks;
 * flush() copies the frame and performs backend calls synchronously on its caller.
 */
class FrameRenderer {
public:
    FrameResult beginFrame(const Viewport& viewport);
    FrameResult line2D(float x1, float y1, float x2, float y2, uint32_t rgba);
    FrameResult outlineRect2D(float left, float top, float right, float bottom,
                              uint32_t rgba);
    FrameResult text2D(float x, float y, const std::string& text, uint32_t rgba);
    FrameResult box3D(const MoonlightVec3V1& min, const MoonlightVec3V1& max,
                      uint32_t rgba);
    FrameResult flush(Backend& backend);
    void cancelFrame();

    std::size_t queuedCommandCount() const;
    uint64_t lastCompletedFrameId() const;

private:
    enum class CommandType { Line2D, Text2D, Box3D };
    struct Command {
        CommandType type = CommandType::Line2D;
        float values[4]{};
        MoonlightVec3V1 min{};
        MoonlightVec3V1 max{};
        uint32_t rgba = 0xFFFFFFFFu;
        std::string text;
    };

    FrameResult append(Command&& command);
    static bool finite(float value);

    mutable std::mutex mutex_;
    Viewport viewport_{};
    uint64_t lastCompletedFrameId_ = 0;
    bool active_ = false;
    std::vector<Command> commands_;
};

}  // namespace moonlight::render
