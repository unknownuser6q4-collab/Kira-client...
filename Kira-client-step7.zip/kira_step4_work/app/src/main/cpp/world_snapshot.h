#pragma once

#include "game_integration.h"

#include <cstddef>
#include <cstdint>
#include <vector>

namespace moonlight::world {

constexpr uint32_t kMaxEntitiesPerSnapshot = 512;
constexpr int32_t kMaxBlockCoordinate = 30000000;

enum class SnapshotResult {
    Ok = 0,
    PlayerUnavailable,
    EntitySourceUnavailable,
    ProviderFailure,
};

struct Snapshot {
    MoonlightPlayerStateV1 player{};
    std::vector<MoonlightEntityStateV1> entities;
    uint32_t providerEntityCount = 0;
    uint32_t rejectedEntityCount = 0;
};

struct QueryResult {
    integration::Result status = integration::Result::Detached;
    uint32_t blockId = 0;
};

/**
 * Bounded, validated read-only snapshot layer. It consumes only the callbacks
 * supplied by a verified provider; it does not locate game objects or hook Bedrock.
 */
class WorldSnapshotReader {
public:
    explicit WorldSnapshotReader(integration::GameIntegration& game);
    SnapshotResult capture(Snapshot* outSnapshot) const;
    QueryResult blockAt(int32_t x, int32_t y, int32_t z) const;
    integration::Result isPlayerEntity(uint64_t runtimeId, bool* outIsPlayer) const;
    integration::Result projectWorldToScreen(const MoonlightVec3V1& world, int32_t width,
                                             int32_t height, MoonlightScreenPointV1* out) const;
    integration::Result readEntityName(uint64_t runtimeId, char* out, uint32_t capacity) const;

    static bool validPlayer(const MoonlightPlayerStateV1& player);
    static bool validEntity(const MoonlightEntityStateV1& entity);
    static float distanceSquared(const MoonlightVec3V1& a, const MoonlightVec3V1& b);

private:
    integration::GameIntegration& game_;
};

}  // namespace moonlight::world
