#include "world_snapshot.h"

#include <cmath>

namespace moonlight::world {
namespace {
bool finite(float v) { return std::isfinite(v); }
bool finiteVec(const MoonlightVec3V1& v) {
    return finite(v.x) && finite(v.y) && finite(v.z) &&
           std::fabs(v.x) <= static_cast<float>(kMaxBlockCoordinate) &&
           std::fabs(v.y) <= static_cast<float>(kMaxBlockCoordinate) &&
           std::fabs(v.z) <= static_cast<float>(kMaxBlockCoordinate);
}
bool validBounds(const MoonlightVec3V1& lo, const MoonlightVec3V1& hi) {
    return finiteVec(lo) && finiteVec(hi) && lo.x <= hi.x && lo.y <= hi.y && lo.z <= hi.z;
}
}

WorldSnapshotReader::WorldSnapshotReader(integration::GameIntegration& game) : game_(game) {}

bool WorldSnapshotReader::validPlayer(const MoonlightPlayerStateV1& p) {
    return finiteVec(p.position) && finite(p.yaw) && finite(p.pitch) &&
           finite(p.health) && p.health >= 0.0f && p.health <= 2048.0f;
}

bool WorldSnapshotReader::validEntity(const MoonlightEntityStateV1& e) {
    return finiteVec(e.position) && validBounds(e.bounds_min, e.bounds_max) &&
           finite(e.health) && e.health >= 0.0f && e.health <= 2048.0f;
}

float WorldSnapshotReader::distanceSquared(const MoonlightVec3V1& a,
                                           const MoonlightVec3V1& b) {
    const float x = a.x - b.x, y = a.y - b.y, z = a.z - b.z;
    return x*x + y*y + z*z;
}

SnapshotResult WorldSnapshotReader::capture(Snapshot* out) const {
    if (out == nullptr) return SnapshotResult::ProviderFailure;
    *out = {};
    if (game_.readPlayer(&out->player) != integration::Result::Ok ||
        !validPlayer(out->player)) return SnapshotResult::PlayerUnavailable;

    uint32_t count = 0;
    const auto countStatus = game_.readEntityCount(&count);
    if (countStatus == integration::Result::CapabilityMissing ||
        countStatus == integration::Result::Detached ||
        countStatus == integration::Result::VersionMismatch ||
        countStatus == integration::Result::BuildMismatch)
        return SnapshotResult::EntitySourceUnavailable;
    if (countStatus != integration::Result::Ok) return SnapshotResult::ProviderFailure;

    out->providerEntityCount = count;
    const uint32_t bounded = count > kMaxEntitiesPerSnapshot ? kMaxEntitiesPerSnapshot : count;
    out->entities.reserve(bounded);
    for (uint32_t i = 0; i < bounded; ++i) {
        MoonlightEntityStateV1 entity{};
        if (game_.readEntity(i, &entity) != integration::Result::Ok || !validEntity(entity)) {
            ++out->rejectedEntityCount;
            continue;
        }
        out->entities.push_back(entity);
    }
    if (count > bounded) out->rejectedEntityCount += count - bounded;
    return SnapshotResult::Ok;
}

integration::Result WorldSnapshotReader::isPlayerEntity(uint64_t runtimeId, bool* out) const {
    return game_.isPlayerEntity(runtimeId, out);
}

integration::Result WorldSnapshotReader::projectWorldToScreen(const MoonlightVec3V1& world,
        int32_t width, int32_t height, MoonlightScreenPointV1* out) const {
    return game_.projectWorldToScreen(world, width, height, out);
}

integration::Result WorldSnapshotReader::readEntityName(uint64_t runtimeId, char* out,
        uint32_t capacity) const {
    return game_.readEntityName(runtimeId, out, capacity);
}

QueryResult WorldSnapshotReader::blockAt(int32_t x, int32_t y, int32_t z) const {
    QueryResult result{};
    if (x < -kMaxBlockCoordinate || x > kMaxBlockCoordinate ||
        y < -kMaxBlockCoordinate || y > kMaxBlockCoordinate ||
        z < -kMaxBlockCoordinate || z > kMaxBlockCoordinate) {
        result.status = integration::Result::CallbackFailed;
        return result;
    }
    result.status = game_.queryBlock(x, y, z, &result.blockId);
    return result;
}

}  // namespace moonlight::world
