#pragma once

#include "game_bridge_api.h"

#include <cstdint>
#include <string>

namespace moonlight::integration {

enum class Result {
    Ok = 0,
    Detached,
    VersionMismatch,
    BuildMismatch,
    CapabilityMissing,
    CallbackFailed,
};

/**
 * Safe consumer facade for a version-specific provider that has registered from
 * inside the game process. This class does not load/inject a provider or discover
 * private Minecraft functions. Those tasks require evidence from the exact APK.
 */
class GameIntegration {
public:
    GameIntegration(std::string expectedVersion, std::string expectedBuildId = {});

    Result refresh();
    bool ready() const;
    std::string gameVersion() const;
    std::string buildId() const;
    uint64_t capabilities() const;

    Result readPlayer(MoonlightPlayerStateV1* outState) const;
    Result readEntityCount(uint32_t* outCount) const;
    Result readEntity(uint32_t index, MoonlightEntityStateV1* outState) const;
    Result readInput(MoonlightInputStateV1* outState) const;
    Result setCamera(const MoonlightVec3V1& position, float yaw, float pitch) const;
    Result setPlayerMotion(const MoonlightVec3V1& velocity) const;
    Result setPlayerFlag(uint32_t flag, bool enabled) const;
    Result setWorldBrightness(float multiplier) const;
    Result drawLine2D(float x1, float y1, float x2, float y2, uint32_t rgba) const;
    Result drawBox3D(const MoonlightVec3V1& min, const MoonlightVec3V1& max,
                     uint32_t rgba) const;
    Result drawText2D(float x, float y, const char* text, uint32_t rgba) const;
    Result queryBlock(int32_t x, int32_t y, int32_t z, uint32_t* outBlockId) const;
    Result isPlayerEntity(uint64_t runtimeId, bool* outIsPlayer) const;
    Result projectWorldToScreen(const MoonlightVec3V1& world, int32_t width, int32_t height,
                                MoonlightScreenPointV1* outPoint) const;
    Result readEntityName(uint64_t runtimeId, char* outName, uint32_t capacity) const;

private:
    Result getBridge(uint64_t requiredCapability, MoonlightGameBridgeV1* out) const;

    std::string expectedVersion_;
    std::string expectedBuildId_;
    std::string gameVersion_;
    std::string buildId_;
    uint64_t capabilities_ = 0;
    bool ready_ = false;
};

}  // namespace moonlight::integration
