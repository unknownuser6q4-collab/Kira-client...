#include "module_runtime.h"

#include <cmath>
#include <cstdlib>
#include <string>
#include <cstdio>

namespace moonlight::modules {
namespace {
constexpr uint32_t kHitboxColor = 0xFF55D6FFu;
constexpr float kDefaultRange = 64.0f;
constexpr float kMaxRange = 512.0f;
constexpr uint32_t kTracerColor = 0xFFFFD166u;
constexpr uint32_t kLabelColor = 0xFFFFFFFFu;
}

ModuleRuntime::ModuleRuntime(ModuleManager& modules, world::WorldSnapshotReader& world,
                             render::FrameRenderer& renderer)
    : modules_(modules), world_(world), renderer_(renderer) {}

float ModuleRuntime::configuredRange(const ModuleManager& modules, const char* moduleId) {
    const std::string raw = modules.setting(moduleId, "range");
    if (raw.empty()) return kDefaultRange;
    char* end = nullptr;
    const float value = std::strtof(raw.c_str(), &end);
    if (end == raw.c_str() || *end != '\0' || !std::isfinite(value) || value <= 0.0f)
        return kDefaultRange;
    return value > kMaxRange ? kMaxRange : value;
}

bool ModuleRuntime::settingEnabled(const ModuleManager& modules, const char* key,
                                   bool defaultValue) {
    const std::string raw = modules.setting("player_esp", key);
    if (raw.empty()) return defaultValue;
    return !(raw == "0" || raw == "false" || raw == "off" || raw == "no");
}

RunStats ModuleRuntime::runFrame(const render::Viewport& viewport, render::Backend& backend) {
    RunStats stats{};
    if (!modules_.enabled("hitbox")) {
        stats.result = RunResult::ModuleDisabled;
        return stats;
    }

    world::Snapshot snapshot;
    if (world_.capture(&snapshot) != world::SnapshotResult::Ok) {
        stats.result = RunResult::ProviderUnavailable;
        return stats;
    }

    const float maxDistanceSquared = configuredRange(modules_);
    const float rangeSquared = maxDistanceSquared * maxDistanceSquared;
    const auto begin = renderer_.beginFrame(viewport);
    if (begin != render::FrameResult::Ok) {
        stats.result = RunResult::RenderFailed;
        return stats;
    }

    for (const auto& entity : snapshot.entities) {
        ++stats.examined;
        if (!entity.alive || entity.runtime_id == 0 ||
            world::WorldSnapshotReader::distanceSquared(snapshot.player.position,
                                                        entity.position) > rangeSquared) {
            ++stats.rejected;
            continue;
        }
        if (renderer_.box3D(entity.bounds_min, entity.bounds_max, kHitboxColor) !=
            render::FrameResult::Ok) {
            ++stats.rejected;
            continue;
        }
        ++stats.rendered;
    }

    if (stats.rendered == 0) {
        renderer_.cancelFrame();
        stats.result = RunResult::NoRenderableEntities;
        return stats;
    }

    stats.result = renderer_.flush(backend) == render::FrameResult::Ok
                       ? RunResult::Rendered : RunResult::RenderFailed;
    if (stats.result == RunResult::RenderFailed) stats.rendered = 0;
    return stats;
}

RunStats ModuleRuntime::runPlayerEspFrame(const render::Viewport& viewport, render::Backend& backend) {
    RunStats stats{};
    if (!modules_.enabled("player_esp")) {
        stats.result = RunResult::ModuleDisabled;
        return stats;
    }

    world::Snapshot snapshot;
    if (world_.capture(&snapshot) != world::SnapshotResult::Ok) {
        stats.result = RunResult::ProviderUnavailable;
        return stats;
    }

    const float range = configuredRange(modules_, "player_esp");
    const float rangeSquared = range * range;
    const auto begin = renderer_.beginFrame(viewport);
    if (begin != render::FrameResult::Ok) {
        stats.result = RunResult::RenderFailed;
        return stats;
    }

    for (const auto& entity : snapshot.entities) {
        ++stats.examined;
        if (!entity.alive || entity.runtime_id == 0 ||
            world::WorldSnapshotReader::distanceSquared(snapshot.player.position,
                                                        entity.position) > rangeSquared) {
            ++stats.rejected;
            continue;
        }
        bool isPlayer = false;
        const auto classification = world_.isPlayerEntity(entity.runtime_id, &isPlayer);
        if (classification != integration::Result::Ok) {
            renderer_.cancelFrame();
            stats.result = RunResult::ClassificationUnavailable;
            stats.rendered = 0;
            return stats; // Fail closed: never label generic entities as players.
        }
        if (!isPlayer) {
            ++stats.rejected;
            continue;
        }
        if (renderer_.box3D(entity.bounds_min, entity.bounds_max, 0xFFFF5A72u) !=
            render::FrameResult::Ok) {
            ++stats.rejected;
            continue;
        }
        ++stats.rendered;
    }

    if (stats.rendered == 0) {
        renderer_.cancelFrame();
        stats.result = RunResult::NoRenderableEntities;
        return stats;
    }
    stats.result = renderer_.flush(backend) == render::FrameResult::Ok
                       ? RunResult::Rendered : RunResult::RenderFailed;
    if (stats.result == RunResult::RenderFailed) stats.rendered = 0;
    return stats;
}


RunStats ModuleRuntime::runPlayerEspDetailsFrame(const render::Viewport& viewport,
                                                  render::Backend& backend) {
    RunStats stats{};
    if (!modules_.enabled("player_esp")) {
        stats.result = RunResult::ModuleDisabled;
        return stats;
    }
    const bool tracersOn = settingEnabled(modules_, "tracers", true);
    const bool namesOn = settingEnabled(modules_, "names", true);
    const bool distanceOn = settingEnabled(modules_, "distance", true);
    if (viewport.width <= 0 || viewport.height <= 0) {
        stats.result = RunResult::ProjectionUnavailable;
        return stats;
    }

    world::Snapshot snapshot;
    if (world_.capture(&snapshot) != world::SnapshotResult::Ok) {
        stats.result = RunResult::ProviderUnavailable;
        return stats;
    }
    const float range = configuredRange(modules_, "player_esp");
    const float rangeSquared = range * range;
    if (renderer_.beginFrame(viewport) != render::FrameResult::Ok) {
        stats.result = RunResult::RenderFailed;
        return stats;
    }

    for (const auto& entity : snapshot.entities) {
        ++stats.examined;
        if (!entity.alive || entity.runtime_id == 0 ||
            world::WorldSnapshotReader::distanceSquared(snapshot.player.position,
                                                        entity.position) > rangeSquared) {
            ++stats.rejected;
            continue;
        }
        bool isPlayer = false;
        if (world_.isPlayerEntity(entity.runtime_id, &isPlayer) != integration::Result::Ok) {
            renderer_.cancelFrame();
            stats.result = RunResult::ClassificationUnavailable;
            stats.rendered = stats.tracers = stats.labels = 0;
            return stats;
        }
        if (!isPlayer) { ++stats.rejected; continue; }

        MoonlightScreenPointV1 screen{};
        MoonlightVec3V1 anchor = entity.position;
        anchor.y = entity.bounds_max.y;
        if ((tracersOn || namesOn || distanceOn) &&
            world_.projectWorldToScreen(anchor, viewport.width, viewport.height, &screen) != integration::Result::Ok) {
            renderer_.cancelFrame();
            stats.result = RunResult::ProjectionUnavailable;
            stats.rendered = stats.tracers = stats.labels = 0;
            return stats;
        }
        if ((tracersOn || namesOn || distanceOn) && !screen.visible) {
            ++stats.rejected;
            continue;
        }
        if (renderer_.box3D(entity.bounds_min, entity.bounds_max, 0xFFFF5A72u) !=
            render::FrameResult::Ok) {
            ++stats.rejected;
            continue;
        }
        ++stats.rendered;

        if (tracersOn) {
            if (renderer_.line2D(static_cast<float>(viewport.width) * 0.5f,
                                 static_cast<float>(viewport.height), screen.x, screen.y,
                                 kTracerColor) == render::FrameResult::Ok) ++stats.tracers;
        }
        char name[96]{};
        std::string label;
        if (namesOn) {
            if (world_.readEntityName(entity.runtime_id, name, sizeof(name)) != integration::Result::Ok) {
                renderer_.cancelFrame();
                stats.result = RunResult::NameUnavailable;
                stats.rendered = stats.tracers = stats.labels = 0;
                return stats;
            }
            label.assign(name);
        }
        if (distanceOn) {
            const float distance = std::sqrt(world::WorldSnapshotReader::distanceSquared(
                snapshot.player.position, entity.position));
            char distanceText[24]{};
            std::snprintf(distanceText, sizeof(distanceText), " %.1fm", distance);
            label += distanceText;
        }
        if (!label.empty() && renderer_.text2D(screen.x, screen.y - 14.0f, label,
                                               kLabelColor) == render::FrameResult::Ok) {
            ++stats.labels;
        }
    }
    if (stats.rendered == 0) {
        renderer_.cancelFrame();
        stats.result = RunResult::NoRenderableEntities;
        return stats;
    }
    stats.result = renderer_.flush(backend) == render::FrameResult::Ok
                       ? RunResult::Rendered : RunResult::RenderFailed;
    if (stats.result == RunResult::RenderFailed)
        stats.rendered = stats.tracers = stats.labels = 0;
    return stats;
}

}  // namespace moonlight::modules
