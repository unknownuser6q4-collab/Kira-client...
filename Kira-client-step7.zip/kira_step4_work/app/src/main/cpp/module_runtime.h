#pragma once

#include "module_manager.h"
#include "render_pipeline.h"
#include "world_snapshot.h"

#include <cstdint>

namespace moonlight::modules {

enum class RunResult {
    Rendered = 0,
    ModuleDisabled,
    ProviderUnavailable,
    NoRenderableEntities,
    RenderFailed,
    ClassificationUnavailable,
    ProjectionUnavailable,
    NameUnavailable,
};

struct RunStats {
    RunResult result = RunResult::ModuleDisabled;
    uint32_t examined = 0;
    uint32_t rendered = 0;
    uint32_t rejected = 0;
    uint32_t tracers = 0;
    uint32_t labels = 0;
};

/**
 * First executable module adapter. It deliberately implements only the read-only
 * hitbox visualization: validated entity bounds are sent to the render backend.
 * It does not classify entity types or alter player/world state.
 */
class ModuleRuntime {
public:
    ModuleRuntime(ModuleManager& modules, world::WorldSnapshotReader& world,
                  render::FrameRenderer& renderer);

    RunStats runFrame(const render::Viewport& viewport, render::Backend& backend);
    RunStats runPlayerEspFrame(const render::Viewport& viewport, render::Backend& backend);
    RunStats runPlayerEspDetailsFrame(const render::Viewport& viewport, render::Backend& backend);

private:
    static float configuredRange(const ModuleManager& modules, const char* moduleId = "hitbox");
    static bool settingEnabled(const ModuleManager& modules, const char* key, bool defaultValue);

    ModuleManager& modules_;
    world::WorldSnapshotReader& world_;
    render::FrameRenderer& renderer_;
};

}  // namespace moonlight::modules
