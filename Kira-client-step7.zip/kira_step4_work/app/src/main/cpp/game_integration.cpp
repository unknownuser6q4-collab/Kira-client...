#include "game_integration.h"

#include <utility>
#include <cmath>

namespace moonlight::integration {

GameIntegration::GameIntegration(std::string expectedVersion, std::string expectedBuildId)
    : expectedVersion_(std::move(expectedVersion)),
      expectedBuildId_(std::move(expectedBuildId)) {}

Result GameIntegration::refresh() {
    ready_ = false;
    capabilities_ = 0;
    gameVersion_.clear();
    buildId_.clear();

    MoonlightBridgeStatusV1 status{};
    if (!moonlight_game_bridge_status_v1(&status) || status.attached == 0) {
        return Result::Detached;
    }

    MoonlightGameBridgeV1 bridge{};
    if (!moonlight_game_bridge_get_v1(&bridge)) return Result::Detached;

    gameVersion_ = bridge.game_version != nullptr ? bridge.game_version : "";
    buildId_ = bridge.game_build_id != nullptr ? bridge.game_build_id : "";
    capabilities_ = bridge.capabilities;

    if (expectedVersion_.empty() || gameVersion_ != expectedVersion_) {
        capabilities_ = 0;
        return Result::VersionMismatch;
    }
    // A build id is mandatory for a production integration. Empty expectedBuildId
    // is useful only for local interface tests and never means "accept any build".
    if (expectedBuildId_.empty() || buildId_.empty() || buildId_ != expectedBuildId_) {
        capabilities_ = 0;
        return Result::BuildMismatch;
    }

    ready_ = true;
    return Result::Ok;
}

bool GameIntegration::ready() const { return ready_; }
std::string GameIntegration::gameVersion() const { return gameVersion_; }
std::string GameIntegration::buildId() const { return buildId_; }
uint64_t GameIntegration::capabilities() const { return ready_ ? capabilities_ : 0; }

Result GameIntegration::getBridge(uint64_t required, MoonlightGameBridgeV1* out) const {
    if (!ready_) return Result::Detached;
    if (out == nullptr || !moonlight_game_bridge_get_v1(out)) return Result::Detached;
    if (out->game_version == nullptr || expectedVersion_ != out->game_version)
        return Result::VersionMismatch;
    if (out->game_build_id == nullptr || expectedBuildId_ != out->game_build_id)
        return Result::BuildMismatch;
    if ((out->capabilities & required) != required) return Result::CapabilityMissing;
    return Result::Ok;
}

#define ML_GET_BRIDGE(cap, bridge) \
    MoonlightGameBridgeV1 bridge{}; \
    const Result status = getBridge((cap), &(bridge)); \
    if (status != Result::Ok) return status
#define ML_CALL(expr) return ((expr) != 0 ? Result::Ok : Result::CallbackFailed)

Result GameIntegration::readPlayer(MoonlightPlayerStateV1* out) const {
    ML_GET_BRIDGE(MOONLIGHT_CAP_PLAYER_READ, b);
    if (out == nullptr || b.get_player_state == nullptr) return Result::CapabilityMissing;
    ML_CALL(b.get_player_state(b.context, out));
}
Result GameIntegration::readEntityCount(uint32_t* out) const {
    ML_GET_BRIDGE(MOONLIGHT_CAP_ENTITY_READ, b);
    if (out == nullptr || b.get_entity_count == nullptr) return Result::CapabilityMissing;
    ML_CALL(b.get_entity_count(b.context, out));
}
Result GameIntegration::readEntity(uint32_t index, MoonlightEntityStateV1* out) const {
    ML_GET_BRIDGE(MOONLIGHT_CAP_ENTITY_READ, b);
    if (out == nullptr || b.get_entity_state == nullptr) return Result::CapabilityMissing;
    ML_CALL(b.get_entity_state(b.context, index, out));
}
Result GameIntegration::readInput(MoonlightInputStateV1* out) const {
    ML_GET_BRIDGE(MOONLIGHT_CAP_INPUT_READ, b);
    if (out == nullptr || b.get_input_state == nullptr) return Result::CapabilityMissing;
    ML_CALL(b.get_input_state(b.context, out));
}
Result GameIntegration::setCamera(const MoonlightVec3V1& p, float yaw, float pitch) const {
    ML_GET_BRIDGE(MOONLIGHT_CAP_CAMERA_CONTROL, b);
    if (b.set_camera == nullptr) return Result::CapabilityMissing;
    ML_CALL(b.set_camera(b.context, &p, yaw, pitch));
}
Result GameIntegration::setPlayerMotion(const MoonlightVec3V1& v) const {
    ML_GET_BRIDGE(MOONLIGHT_CAP_PLAYER_CONTROL, b);
    if (b.set_player_motion == nullptr) return Result::CapabilityMissing;
    ML_CALL(b.set_player_motion(b.context, &v));
}
Result GameIntegration::setPlayerFlag(uint32_t flag, bool enabled) const {
    ML_GET_BRIDGE(MOONLIGHT_CAP_PLAYER_CONTROL, b);
    if (b.set_player_flag == nullptr) return Result::CapabilityMissing;
    ML_CALL(b.set_player_flag(b.context, flag, enabled ? 1 : 0));
}
Result GameIntegration::setWorldBrightness(float multiplier) const {
    ML_GET_BRIDGE(MOONLIGHT_CAP_WORLD_LIGHTING, b);
    if (b.set_world_brightness == nullptr) return Result::CapabilityMissing;
    ML_CALL(b.set_world_brightness(b.context, multiplier));
}
Result GameIntegration::drawLine2D(float x1, float y1, float x2, float y2, uint32_t rgba) const {
    ML_GET_BRIDGE(MOONLIGHT_CAP_OVERLAY_2D, b);
    if (b.draw_line_2d == nullptr) return Result::CapabilityMissing;
    ML_CALL(b.draw_line_2d(b.context, x1, y1, x2, y2, rgba));
}
Result GameIntegration::drawBox3D(const MoonlightVec3V1& min, const MoonlightVec3V1& max,
                                  uint32_t rgba) const {
    ML_GET_BRIDGE(MOONLIGHT_CAP_OVERLAY_3D, b);
    if (b.draw_box_3d == nullptr) return Result::CapabilityMissing;
    ML_CALL(b.draw_box_3d(b.context, &min, &max, rgba));
}
Result GameIntegration::drawText2D(float x, float y, const char* text, uint32_t rgba) const {
    ML_GET_BRIDGE(MOONLIGHT_CAP_OVERLAY_2D, b);
    if (text == nullptr || b.draw_text_2d == nullptr) return Result::CapabilityMissing;
    ML_CALL(b.draw_text_2d(b.context, x, y, text, rgba));
}
Result GameIntegration::queryBlock(int32_t x, int32_t y, int32_t z, uint32_t* out) const {
    ML_GET_BRIDGE(MOONLIGHT_CAP_BLOCK_QUERY, b);
    if (out == nullptr || b.query_block == nullptr) return Result::CapabilityMissing;
    ML_CALL(b.query_block(b.context, x, y, z, out));
}
Result GameIntegration::isPlayerEntity(uint64_t runtimeId, bool* out) const {
    ML_GET_BRIDGE(MOONLIGHT_CAP_PLAYER_CLASSIFY, b);
    if (runtimeId == 0 || out == nullptr || b.is_player_entity == nullptr)
        return Result::CapabilityMissing;
    uint8_t value = 0;
    if (b.is_player_entity(b.context, runtimeId, &value) == 0) return Result::CallbackFailed;
    if (value > 1) return Result::CallbackFailed;
    *out = value == 1;
    return Result::Ok;
}

Result GameIntegration::projectWorldToScreen(const MoonlightVec3V1& world, int32_t width,
                                             int32_t height, MoonlightScreenPointV1* out) const {
    ML_GET_BRIDGE(MOONLIGHT_CAP_WORLD_TO_SCREEN, b);
    if (out == nullptr || width <= 0 || height <= 0 || b.project_world_to_screen == nullptr)
        return Result::CapabilityMissing;
    MoonlightScreenPointV1 point{};
    if (b.project_world_to_screen(b.context, &world, width, height, &point) == 0)
        return Result::CallbackFailed;
    if (!std::isfinite(point.x) || !std::isfinite(point.y) || point.visible > 1)
        return Result::CallbackFailed;
    *out = point;
    return Result::Ok;
}
Result GameIntegration::readEntityName(uint64_t runtimeId, char* out, uint32_t capacity) const {
    ML_GET_BRIDGE(MOONLIGHT_CAP_ENTITY_NAME, b);
    if (runtimeId == 0 || out == nullptr || capacity < 2 || b.get_entity_name == nullptr)
        return Result::CapabilityMissing;
    out[0] = '\0';
    if (b.get_entity_name(b.context, runtimeId, out, capacity) == 0)
        return Result::CallbackFailed;
    out[capacity - 1] = '\0';
    return out[0] == '\0' ? Result::CallbackFailed : Result::Ok;
}

#undef ML_GET_BRIDGE
#undef ML_CALL

}  // namespace moonlight::integration
