# Step 1 — Minecraft APK static inventory

This step adds a **read-only static APK inspection workflow**. It does not modify,
install, launch, inject into, or attach to Minecraft. It gathers verifiable facts
needed before designing a version-specific integration.

## Required input

Use the exact original Minecraft Bedrock APK you intend to target (expected
`versionName` 1.26.60, ARM64). Do not use the Kira client APK as the target input.
Keep the original APK unchanged and record where it came from. The APK filename
is not proof of its version; the report compares decoded package metadata when
Android SDK Build Tools are available.

## Run the inspector

Python 3.10+ is sufficient for the core inventory; there are no pip dependencies.
From the project root:

```bash
python3 tools/apk_inspector.py /path/to/Minecraft.apk \
  --expected-version 1.26.60 \
  --out artifacts/minecraft-1.26.60-audit
```

The tool checks ZIP integrity, records the APK SHA-256, inventories package
entries, detects ABI folders, inspects ELF headers and `DT_NEEDED` dependencies
for native `.so` libraries, and extracts those libraries into the audit output
folder for read-only follow-up analysis. If `readelf` or `llvm-readelf` is
available, it also captures ELF header, dynamic-section and symbol-table output.
If Android SDK `apkanalyzer` and/or `aapt` is available, it captures manifest
and package metadata output, including version evidence where exposed.

Outputs:

- `report.md` — human-readable findings and interpretation limits.
- `report.json` — full machine-readable inventory and tool output.
- `native-libraries/<abi>/*.so` — extracted native libraries for further static
  analysis. These are copies; the APK itself is not changed.

## Optional analysis tools

Install Android SDK Build Tools to provide `apkanalyzer` and `aapt`; install GNU
`readelf` or LLVM `llvm-readelf` for deeper ELF metadata. JADX may be used for
manual DEX inspection if the Android-side package loading path needs review.
Use official tool distributions and do not execute code extracted from the APK.

## What Step 1 can and cannot establish

It can establish the APK's cryptographic hash, ZIP contents, ABI directories,
ELF class/machine, build IDs (when present), SONAMEs, and dynamic dependencies.
It can identify candidate native engine libraries by name for further inspection.

It cannot prove that a native library is the one performing a modification,
that a library is loaded at runtime, how the game initializes in memory, that a
hook is valid, or that a module works. `DT_NEEDED` does not enumerate libraries
loaded later with `dlopen()`. Stripped symbols, obfuscation, split APK delivery,
and version-specific native changes may require additional evidence. No offsets,
private function signatures, or runtime behavior are guessed by this tool.

## Step 1 exit criteria

Before moving on, the report should establish:

1. The APK package name and decoded version metadata (or clearly record why the
   tools could not decode it).
2. The APK's SHA-256 and ZIP integrity.
3. The ABI directories and whether an ARM64 game library is present.
4. The ELF architecture and dynamic dependencies of every native library.
5. Which candidate libraries need deeper manual inspection, without claiming
   that names alone prove their role.

A matching `versionName` is not sufficient proof that the binary is the expected
build. Keep the original APK hash with all later analysis notes.
