# Moonlight

Moonlight is an Android overlay client for Minecraft Bedrock. A floating moon button
sits over the game, and tapping it opens a touch-first module panel with Combat,
Movement, Render, Player and Base Finding categories, a search field, a scrollbar and
an ON/OFF toggle on every module.

The project is a normal Android application written in Kotlin. It is **not** a
resource pack, behaviour pack or add-on, and it is **not** a modified Minecraft APK.

---

## Read this first: what can and cannot affect Minecraft

An ordinary Android app is sandboxed. It cannot read another app's memory, cannot
see Minecraft's world data and cannot draw into Minecraft's render pipeline. Every
module that needs world data (Storage ESP, Block ESP, Geode Finder, Light Source
Finder, Sus Chunk, Stash Finder, Logout Spots, Player ESP, Spectator Glow) and every
module that needs the camera or lighting (Fullbright, Freecam, Freelook) therefore
only works when code is running **inside Minecraft's own process**.

Moonlight handles this honestly:

- Every module can be toggled, configured, searched and exported today.
- The panel marks hook-only modules `NO HOOK` while no hook is attached, and the
  launcher screen shows the real host state.
- Nothing pretends to be editing the game. When a hook is attached, the badge
  disappears and the HUD reports `hook attached`.

Two legitimate ways to attach a hook:

1. **Rooted device.** A root loader injects a library into the Minecraft process
   (`com.mojang.minecraftpe`). Android's sandbox is bypassed by root, not by this app.
2. **Self-built patched host.** You build your own copy of a Bedrock-compatible host
   that loads the bridge library. Reverse engineering and redistributing Mojang's
   proprietary APK is not something this repository does or ships.

Without one of those, the app is a complete, installable configuration client for
those modules, and the overlay/HUD/eye-shortcut surfaces work normally.

### Hook contract

A hook that wants the panel to report it as live writes a heartbeat to the app's own
files directory:

```
/data/data/com.moonlight.bedrockclient/files/moonlight-bridge/status.json
```

```json
{ "pid": 12345, "version": "2.0.0", "timestamp": 1760000000000 }
```

The heartbeat counts as attached while `timestamp` is less than 120 seconds old and
`pid` is non-zero. `HostBridge.detect()` is the single reader.

---

## What is in the panel

| Category | Modules |
| --- | --- |
| Combat | Aimbot, Triggerbot, Reach, Velocity, Auto Clicker, Hitboxes |
| Movement | Flight, Freeze, Elytra Fly, No Fall, Sprint, Keep Sprint, Bhop, Scaffold |
| Render | Fullbright, Freecam, Freelook, HUD |
| Player | Player ESP, Spectator Glow |
| Base Finding | Storage ESP, Geode Finder, Light Source Finder, Sus Chunk Finder, Block ESP, Stash Finder, Logout Spots |
| General | Panel, Theme, Configs, Touch, About |

Highlights:

- **Storage ESP** ships a master toggle plus 17 individually toggleable block types
  (shulker boxes, chests, trapped chests, hoppers, ender chests, droppers,
  dispensers, smokers, furnaces, blast furnaces, note blocks, pistons, sticky
  pistons, barrels, item frames, crafters, brewing stands), each with its own color.
- **Block ESP** has its own block list, box style and tracer settings.
- **Freecam** exposes speed, no-clip, player lock, smooth camera, camera HUD,
  joystick size, button size, control opacity, joystick side and a reset action.- **Freelook** has hold/toggle activation, a sensitivity slider, and an eye shortcut that appears as a draggable bubble when the module is on.
- **Base finding** modules carry distance, threshold, tracer, diagnostics and
  player-modification filters.
- **Configs** exports and imports the whole configuration as JSON.

Everything above is real state: toggles persist in
`files/moonlight/config.json`, survive restarts and are shared between the panel,
the launcher screen and the settings screen.

---

## Install

1. Download `Moonlight-debug-APK` from the latest **Actions** run, or build locally.
2. On the phone, allow installs from the app you are using to open the APK.
3. If an older build is installed, **uninstall it first**. Older builds were signed
   with a throwaway debug key, so Android refuses to replace them and Samsung
   reports "App not installed" / the package appears to be invalid.

Then open Moonlight, grant **Display over other apps**, start the overlay and launch
Minecraft. A moon button appears; tap it for the panel.

---

## Why the previous APK would not install or run

These were the underlying problems addressed in this tree:

1. **Signing changed on every CI run.** `assembleDebug` used the runner's
   auto-generated debug keystore, so every Actions artifact had a different
   signature. Installing a newer build over an older one fails with
   `INSTALL_FAILED_UPDATE_INCOMPATIBLE`, which Samsung surfaces as "App not
   installed as package appears to be invalid". CI debug builds use a runner-generated
   key, so reinstall may be needed when the runner key changes.
2. **Android 14 foreground service crash.** The manifest declared
   `foregroundServiceType="specialUse"` without the
   `FOREGROUND_SERVICE_SPECIAL_USE` permission and without the required
   `android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE` property. `startForeground` threw
   a `SecurityException` and the service died immediately. Both are now declared,
   plus `POST_NOTIFICATIONS` for Android 13 and later.
3. **`QUERY_ALL_PACKAGES`** was used to find Minecraft. Replaced with a narrow
   `<queries>` entry for `com.mojang.minecraftpe`.
4. **Broken native payload.** The old CMake targets called `dlopen` inside
   Moonlight's own process, so they could never touch Minecraft, while still
   forcing an NDK download and two ABI build variants. An app that declares
   `arm64-v8a` and `armeabi-v7a` but ships mismatched native code is a common cause
   of install and launch failures on 32-bit capable devices. Those targets were
   removed. A new, honest native engine now ships **one** `arm64-v8a` library (see
   [Native engine](#native-engine)); the manifest advertises only that ABI, so the
   declared and shipped ABIs always match.
5. **A `wrap.sh` in `src/main/resources`** was never packaged into the APK and
   hinted at `LD_PRELOAD` injection that Android will not perform for you. Removed.
6. **Portrait-only activity** was wrong for a landscape game overlay. The launcher
   now follows device rotation and the overlay re-lays out on configuration change.
7. **No Gradle wrapper and no version pinning.** The build now pins AGP 8.1.1,
   Kotlin 1.9.0, Gradle 8.2 and Java 17, and CI installs API 34 and build-tools 34
   explicitly.

### About signing

No signing private key or password is included in this repository. CI produces a
debug APK signed with the runner-generated debug key. For a distributable release,
configure your own private keystore locally and keep it out of Git. Changing signing
identity may require uninstalling an older build before installing the new one.

---

## Build

Local build needs JDK 17 and Android SDK platform 34 + build-tools 34.0.0:

```bash
export ANDROID_SDK_ROOT=/path/to/android-sdk
export JAVA_HOME=/path/to/jdk-17
./gradlew :app:assembleDebug
```

If the SDK is not in a default location, either export `ANDROID_SDK_ROOT` or write
`sdk.dir=/path/to/android-sdk` into `local.properties` (git-ignored). The wrapper
fetches Gradle 8.2 on first run, so the first build also needs network access.

Output: `app/build/outputs/apk/debug/app-debug.apk`.

GitHub Actions builds a debug APK on every push to `app/**` and uploads it as the
`Moonlight-debug-APK` artifact after verifying the signature with `apksigner`.

### Verification status for this update

The native module-setting and bridge-registry code passed the included C++17 smoke
test (`bash scripts/test-native-bridge.sh`) with `-Wall -Wextra -Werror`. GitHub Actions
now runs this test before attempting the Android build. An Android APK
build could not be run in the current environment because no Android SDK is
configured and the Gradle 8.2 distribution could not be downloaded. GitHub Actions
is configured to perform the Android build. No live Minecraft integration test has
been performed; gameplay modules remain pending a real, version-matched provider.

---

## Project layout

```
app/src/main/java/com/moonlight/bedrockclient/
├─ MainActivity.kt              launcher, permissions, host status
├─ AppSettingsActivity.kt       app-level settings bound to the same config
├─ FloatingOverlayService.kt    moon bubble, panel window, eye, HUD
├─ core/
│  ├─ Module.kt                 category, setting and module model
│  ├─ ModuleRegistry.kt         the full module catalogue
│  ├─ ConfigStore.kt            JSON persistence, import/export, ConfigHolder
│  ├─ HostBridge.kt             Minecraft install, root and hook heartbeat detection
│  └─ NativeEngine.kt           JNI front door, safe no-op without the library
└─ ui/
   ├─ ClickGuiView.kt           custom drawn panel, search keyboard, touch handling
   ├─ EyeHandleView.kt          Freelook eye shortcut bubble
   └─ GuiTheme.kt               accent presets and palette
app/src/main/cpp/
├─ CMakeLists.txt               single arm64-v8a shared library
├─ engine.cpp                  100 Hz scheduler thread and timing telemetry
├─ module_manager.cpp          thread-safe module and setting mirror
├─ hook_registry.cpp           attached/detached/stale heartbeat state
├─ game_bridge_api.h           versioned in-process provider ABI contract
├─ game_bridge_registry.cpp    provider ABI and capability validation
├─ game_integration.h/.cpp    version/build-gated typed provider facade
├─ world_snapshot.h/.cpp       bounded player/entity/block snapshot reader
└─ jni_bridge.cpp              the JNI surface behind NativeEngine.kt
```

---

## Native engine

`app/src/main/cpp` builds `libmoonlight_engine.so` for **arm64-v8a only**, using the
pinned NDK `26.1.10909125` and CMake `3.22.1`.

| File | Role |
| --- | --- |
| `engine.cpp` | one worker thread at 100 Hz, start/stop, tick/mean/peak microsecond telemetry |
| `module_manager.cpp` | mutex-guarded registry of module ids, enabled flags, setting values and toggle counters |
| `hook_registry.cpp` | `attached` / `stale` / `detached` state for an in-process bridge |
| `jni_bridge.cpp` | the symbols `core/NativeEngine.kt` calls |

Wiring: `ConfigStore` pushes each toggle into the native mirror
(`NativeEngine.setEnabled` and `NativeEngine.setSetting`), and re-syncs the whole
catalogue and saved settings on load, import and reset. The `About` page shows a `Native engine` row reading real counters from the
running thread (`arm64-v8a 100Hz <ticks> ticks, <us> mean, <n>/<m> enabled`).

**What it does not do:** change Minecraft. The library loads into Moonlight's own
process, so it has no access to the game's memory. `HookRegistry` therefore starts
`detached`, and only reports `attached` when `HostBridge` sees a genuine heartbeat at
`files/moonlight-bridge/status.json`. Hook-only modules keep their inactive label
until that happens; the native layer never fabricates the state.

Because the APK ships one arm64 library and declares only that ABI, it installs on
arm64 devices (which is what 64-bit Bedrock requires). On a 32-bit device
`NativeEngine.available` is `false` and every call is a no-op — though the APK itself
will not install there.

---


## Step 3 — rendering pipeline foundation

Step 3 adds a bounded native frame-command queue and a `GameBridgeBackend` adapter
for 2D lines, text, and 3D boxes. The adapter delegates only through the exact
version/build-verified provider callbacks. Run `scripts/test-render-pipeline.sh` to
exercise frame lifecycle, command validation, queue limits, failure handling, and
mock-provider delegation. See [STEP_3_RENDERING.md](STEP_3_RENDERING.md).

This is a rendering foundation, not a Minecraft renderer hook or provider. A real
game-side provider must register the verified callbacks and call the renderer from
Minecraft's actual render callback on the proper render thread/context. The existing
Android overlay is not equivalent to in-game rendering.

## Third-party archives

An earlier revision of this repository carried `LuminaClient-main.zip`, an unrelated
third-party Bedrock client (Pixie/ImGui GUI, protocol relay, Xbox auth). It was never
imported into this project: 0 of its 9,867 files are referenced anywhere in the
Gradle build or the Kotlin sources. The archive has been removed from the working
tree and `LuminaClient*.zip` is now git-ignored. It remains recoverable from git
history if you need it back.


## Step 1 — target Minecraft APK inspection

A read-only APK inspection toolkit is included at `tools/apk_inspector.py`. It
inventories APK contents and ABI folders, checks ZIP integrity, records SHA-256
hashes, parses native ELF headers and `DT_NEEDED` dependencies, and uses
`readelf`/`llvm-readelf` plus Android SDK tools when available. It does not
install, modify, launch, inject into, or attach to Minecraft.

Run it against the exact original Minecraft APK (not this client APK):

```bash
python3 tools/apk_inspector.py /path/to/Minecraft.apk \
  --expected-version 1.26.60 \
  --out artifacts/minecraft-1.26.60-audit
```

The output includes `report.md`, `report.json`, and extracted native-library
copies under `native-libraries/`. See [STEP_1_APK_ANALYSIS.md](STEP_1_APK_ANALYSIS.md)
for setup, interpretation limits, and exit criteria. Android SDK Build Tools are
needed to decode package/version metadata from the binary manifest.

## Native integration update

This update adds native setting synchronization and a versioned C ABI contract for a separate in-process game provider. It does not ship a Minecraft-specific provider or claim the gameplay modules are operational. Read [MODULE_INTEGRATION_STATUS.md](MODULE_INTEGRATION_STATUS.md) before treating any module as functional.


## Step 2 — version-gated native integration layer

Step 2 originally introduced ABI v2 with exact build identity, capability-to-callback validation,
and a typed C++ consumer facade. It refuses to expose game capabilities unless a
provider registers with the exact expected version and build ID. See
[STEP_2_INTEGRATION_LAYER.md](STEP_2_INTEGRATION_LAYER.md). This is not a
Minecraft-specific provider: the exact target APK and a verified, authorized
in-process provider are still required before any gameplay module can work.


## Step 4 — world data layer

See [`STEP_4_WORLD_INTEGRATION.md`](STEP_4_WORLD_INTEGRATION.md) for the bounded, validated player/entity snapshot reader and block-query wrapper. It requires a real exact-build provider; it does not itself attach to Minecraft.


## Step 5 — first native module runtime

The native module runtime now connects module enable state to validated world snapshots
and the rendering queue. `hitbox` is the first executable module: it draws bounds for
alive entities within `hitbox.range` (default 64, maximum 512). It is read-only and does
not modify the game. The current provider contract has no player-type classification, so
this is entity-bounds visualization rather than player-only ESP. Run
`./scripts/test-module-runtime.sh` for the host-side fixture test. A real Bedrock provider
and in-game render callback are still required for live operation.


## Step 6 — player classification and Player ESP runtime

ABI v3 adds an explicit provider callback for player-vs-non-player classification. The `player_esp` native runtime draws bounds only for positively classified players and fails closed if classification is unavailable. It uses `player_esp.range` (default 64, maximum 512). This is tested with host-side fake providers/renderers only; no Minecraft-specific classifier, live attachment, or in-game render callback is included. Rebuild any provider against the ABI v3 header. See [STEP_6_PLAYER_ESP.md](STEP_6_PLAYER_ESP.md).


ABI v4 adds provider callbacks for world-to-screen projection and bounded entity-name reads. The Player ESP details runtime can draw tracers from the bottom-center of the viewport, player names, and distance labels, alongside player-only boxes. Settings `player_esp.tracers`, `player_esp.names`, and `player_esp.distance` default on. These paths are covered by fake-provider tests only; the project still has no verified Bedrock provider, so no live Minecraft rendering is claimed. Rebuild any provider against the ABI v4 header. See [STEP_7_PLAYER_ESP_DETAILS.md](STEP_7_PLAYER_ESP_DETAILS.md).
