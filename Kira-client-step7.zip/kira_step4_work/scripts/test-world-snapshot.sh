#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${TMPDIR:-/tmp}/moonlight-world-snapshot-test"
mkdir -p "$OUT"
CXX_BIN="${CXX:-c++}"
"$CXX_BIN" -std=c++17 -Wall -Wextra -Werror -I"$ROOT/app/src/main/cpp" \
  "$ROOT/tests/world_snapshot_smoke.cpp" \
  "$ROOT/app/src/main/cpp/game_bridge_registry.cpp" \
  "$ROOT/app/src/main/cpp/game_integration.cpp" \
  "$ROOT/app/src/main/cpp/world_snapshot.cpp" -o "$OUT/world_snapshot_smoke"
"$OUT/world_snapshot_smoke"
echo "World snapshot smoke test passed."
