#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="$(mktemp -d)"
trap 'rm -rf "$BUILD_DIR"' EXIT
c++ -std=c++17 -Wall -Wextra -Werror -pthread \
  -I "$ROOT/app/src/main/cpp" \
  "$ROOT/app/src/main/cpp/game_bridge_registry.cpp" \
  "$ROOT/app/src/main/cpp/game_integration.cpp" \
  "$ROOT/app/src/main/cpp/render_pipeline.cpp" \
  "$ROOT/tests/render_pipeline_smoke.cpp" \
  -o "$BUILD_DIR/render_pipeline_smoke"
"$BUILD_DIR/render_pipeline_smoke"
echo "Rendering pipeline smoke test passed."
