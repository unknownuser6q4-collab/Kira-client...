#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${TMPDIR:-/tmp}/moonlight-module-runtime-test"
mkdir -p "$OUT"
CXX_BIN="${CXX:-c++}"
"$CXX_BIN" -std=c++17 -Wall -Wextra -Werror -I"$ROOT/app/src/main/cpp" \
  "$ROOT/tests/module_runtime_smoke.cpp" \
  "$ROOT/app/src/main/cpp/module_manager.cpp" \
  "$ROOT/app/src/main/cpp/game_bridge_registry.cpp" \
  "$ROOT/app/src/main/cpp/game_integration.cpp" \
  "$ROOT/app/src/main/cpp/world_snapshot.cpp" \
  "$ROOT/app/src/main/cpp/render_pipeline.cpp" \
  "$ROOT/app/src/main/cpp/module_runtime.cpp" -o "$OUT/module_runtime_smoke"
"$OUT/module_runtime_smoke"
echo "Module runtime smoke test passed."
