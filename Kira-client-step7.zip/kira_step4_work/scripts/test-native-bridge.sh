#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="$(mktemp -d)"
trap 'rm -rf "$BUILD_DIR"' EXIT
c++ -std=c++17 -Wall -Wextra -Werror \
  -I "$ROOT/app/src/main/cpp" \
  "$ROOT/app/src/main/cpp/module_manager.cpp" \
  "$ROOT/app/src/main/cpp/game_bridge_registry.cpp" \
  "$ROOT/app/src/main/cpp/game_integration.cpp" \
  "$ROOT/tests/native_bridge_smoke.cpp" \
  -o "$BUILD_DIR/native_bridge_smoke"
"$BUILD_DIR/native_bridge_smoke"
echo "Native bridge smoke test passed."
